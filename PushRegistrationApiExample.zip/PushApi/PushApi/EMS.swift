//
//  EMS.swift
//  PushApi
//
//  Created by Stephen Benelisha on 10/8/15.
//  Copyright © 2015 experian. All rights reserved.
//

import UIKit

class EMS {
    var window: UIWindow?
    var viewController:ViewController?
    
    let custId = "100"
    let appId = "98dd6dbb-8d0b-4450-91ed-85ce46e5febb"
    let hostName = "cs.sbox.eccmp.com"
    var tokenString:String = ""
    var prid:String = ""
    
    convenience init(view: ViewController, tokenStr: String) {
        self.init()
        self.viewController = view
        self.tokenString = tokenStr
    }
    
    convenience init(view: ViewController) {
        self.init()
        self.viewController = view
    }
    
    func GET() {
        let sessionConfig = NSURLSessionConfiguration.defaultSessionConfiguration()
        
        /* Create session, and optionally set a NSURLSessionDelegate. */
        let session = NSURLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
        /* Create the Request:
        GET (GET http://cs.sbox.eccmp.com/xts/registration/cust/100/application/b1a12919-b1ff-44b2-ac48-21157e33d0a4/token/fc7815eccb1acc401598cab834149113c138d4c5c52abe345e1798621283ae14)
        */
        
        let URL = NSURL(string: "http://\(self.hostName)/xts/registration/cust/\(self.custId)/application/\(self.appId)/token/\(self.tokenString)")
        
        let request = NSMutableURLRequest(URL: URL!)
        request.HTTPMethod = "GET"
        
        /* Start a new Task */
        let task = session.dataTaskWithRequest(request, completionHandler: { (data : NSData?, response : NSURLResponse?, error : NSError?) -> Void in
            if (error == nil) {
                // Success
                let statusCode = (response as! NSHTTPURLResponse).statusCode
                print("URL GET Session Task Succeeded: HTTP \(statusCode)")
                self.printToMainThread(self.viewController!.STATUS, message: "URL GET Session Task Succeeded: HTTP \(statusCode)");
                
                let responseDictionary:NSDictionary =
                (try! NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers)) as! NSDictionary
                
                print("Response: \(responseDictionary)")
                let pridArray = responseDictionary["registrationIds"] as! NSArray
                self.prid = pridArray[0] as! String
                self.printToMainThread(self.viewController!.PRID, message: self.prid)
            }
            else {
                // Failure
                print("URL GET Session Task Failed: %@", error!.localizedDescription);
                self.printToMainThread(self.viewController!.STATUS, message: "URL GET Session Task Failed: \(error!.localizedDescription)")
            }
        })
        task.resume()
    }
    
    func POST() {
        let sessionConfig = NSURLSessionConfiguration.defaultSessionConfiguration()
        
        /* Create session, and optionally set a NSURLSessionDelegate. */
        let session = NSURLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
        /* Create the Request:
        My API (POST http://cs.sbox.eccmp.com/xts/registration/cust/100/application/b1a12919-b1ff-44b2-ac48-21157e33d0a4/token/fc7815eccb1acc401598cab834149113c138d4c5c52abe345e1798621283ae14)
        */
        
        let URL = NSURL(string: "http://\(self.hostName)/xts/registration/cust/\(self.custId)/application/\(self.appId)/token/\(self.tokenString)")
        let request = NSMutableURLRequest(URL: URL!)
        request.HTTPMethod = "POST"
        
        /* Start a new Task */
        let task = session.dataTaskWithRequest(request, completionHandler: { (data : NSData?, response : NSURLResponse?, error : NSError?) -> Void in
            if (error == nil) {
                // Success
                let statusCode = (response as! NSHTTPURLResponse).statusCode
                if(statusCode == 200 || statusCode == 201) {
                    print("URL POST Session Task Succeeded: HTTP \(statusCode)")
                    self.printToMainThread(self.viewController!.STATUS, message: "URL POST Session Task Succeeded: HTTP \(statusCode)");
                    let responseDictionary:NSDictionary =
                    (try! NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers)) as! NSDictionary
                    self.prid = responseDictionary["Push_Registration_Id"] as! String
                    self.printToMainThread(self.viewController!.PRID, message: self.prid)
                } else {
                    print("URL POST Unexpected Status: HTTP \(statusCode)")
                    self.printToMainThread(self.viewController!.STATUS, message: "URL POST Unexpected Status: HTTP \(statusCode)");
                }
            }
            else {
                // Failure
                print("URL POST Session Task Failed: %@", error!.localizedDescription);
                self.printToMainThread(self.viewController!.STATUS, message: "URL POST Session Task Failed: \(error!.localizedDescription)")
            }
        })
        task.resume()
    }
    
    
    ///  PUT with token in URI
    func PUT(tokenString:String) {
        let sessionConfig = NSURLSessionConfiguration.defaultSessionConfiguration()
        
        /* Create session, and optionally set a NSURLSessionDelegate. */
        let session = NSURLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
        /* Create the Request:
        PUT (PUT http://cs.sbox.eccmp.com/xts/registration/cust/100/application/b1a12919-b1ff-44b2-ac48-21157e33d0a4/registration/d063909d-d8ba-4002-9fb5-978568f4b697/token/fd7815eccb1acc401598cab834149113c138d4c5c52abe345e1798621283ae14)
        */
        
        let URL = NSURL(string: "http://\(self.hostName)/xts/registration/cust/\(self.custId)/application/\(self.appId)/registration/\(self.prid)/token/\(tokenString)")
        let request = NSMutableURLRequest(URL: URL!)
        request.HTTPMethod = "PUT"
        
        /* Start a new Task */
        let task = session.dataTaskWithRequest(request, completionHandler: { (data : NSData?, response : NSURLResponse?, error : NSError?) -> Void in
            if (error == nil) {
                let statusCode = (response as! NSHTTPURLResponse).statusCode
                if(statusCode == 200 || statusCode == 201) {
                    // Success
                    let statusCode = (response as! NSHTTPURLResponse).statusCode
                    print("URL PUT Session Task Succeeded: HTTP \(statusCode)")
                    self.printToMainThread(self.viewController!.STATUS, message: "URL PUT Session Task Succeeded: HTTP \(statusCode)");
                } else {
                    print("URL PUT Unexpected Status: HTTP \(statusCode)")
                    self.printToMainThread(self.viewController!.STATUS, message: "URL PUT Unexpected Status: HTTP \(statusCode)");
                }
            } else {
                // Failure
                print("URL PUT Session Task Failed: %@", error!.localizedDescription);
                self.printToMainThread(self.viewController!.STATUS, message: "URL PUT Session Task Failed: \(error!.localizedDescription)")
            }
        })
        task.resume()
    }
    
    ///  PUT with token in BODY
    func _PUT(tokenString:String) {
        let sessionConfig = NSURLSessionConfiguration.defaultSessionConfiguration()
        
        /* Create session, and optionally set a NSURLSessionDelegate. */
        let session = NSURLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
        /* Create the Request:
        PUT [APN Token in BODY] (PUT http://cs.sbox.eccmp.com/xts/registration/cust/100/application/b1a12919-b1ff-44b2-ac48-21157e33d0a4/registration/d063909d-d8ba-4002-9fb5-978568f4b697/token)
        */
        
        let URL = NSURL(string: "http://\(self.hostName)/xts/registration/cust/\(self.custId)/application/\(self.appId)/registration/\(self.prid)/token")
        let request = NSMutableURLRequest(URL: URL!)
        request.HTTPMethod = "PUT"
        
        // Headers
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // JSON Body
        
        let bodyObject = [
            "DeviceToken": tokenString
        ]

        request.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(bodyObject, options: [])
        
        /* Start a new Task */
        let task = session.dataTaskWithRequest(request, completionHandler: { (data : NSData?, response : NSURLResponse?, error : NSError?) -> Void in
            if (error == nil) {
                let statusCode = (response as! NSHTTPURLResponse).statusCode
                if(statusCode == 200 || statusCode == 201) {
                    // Success
                    let statusCode = (response as! NSHTTPURLResponse).statusCode
                    print("URL PUT Session Task Succeeded: HTTP \(statusCode)")
                    self.printToMainThread(self.viewController!.STATUS, message: "URL PUT Session Task Succeeded: HTTP \(statusCode)");
                } else {
                    print("URL PUT Unexpected Status: HTTP \(statusCode)")
                    self.printToMainThread(self.viewController!.STATUS, message: "URL PUT Unexpected Status: HTTP \(statusCode)");
                }
            }
            else {
                // Failure
                print("URL Session Task Failed: %@", error!.localizedDescription);
                self.printToMainThread(self.viewController!.STATUS, message: "URL PUT Session Task Failed: \(error!.localizedDescription)")
            }
        })
        task.resume()
    }
    
    func DELETE() {
        let sessionConfig = NSURLSessionConfiguration.defaultSessionConfiguration()
        
        /* Create session, and optionally set a NSURLSessionDelegate. */
        let session = NSURLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
        /* Create the Request:
        DELETE (DELETE http://cs.sbox.eccmp.com/xts/registration/cust/100/application/b1a12919-b1ff-44b2-ac48-21157e33d0a4/token/fd7815eccb1acc401598cab834149113c138d4c5c52abe345e1798621283ae14)
        */
        
        let URL = NSURL(string: "http://\(self.hostName)/xts/registration/cust/\(self.custId)/application/\(self.appId)/token/\(self.tokenString)")
        let request = NSMutableURLRequest(URL: URL!)
        request.HTTPMethod = "DELETE"
        
        /* Start a new Task */
        let task = session.dataTaskWithRequest(request, completionHandler: { (data : NSData?, response : NSURLResponse?, error : NSError?) -> Void in
            if (error == nil) {
                // Success
                let statusCode = (response as! NSHTTPURLResponse).statusCode
                let result = NSString(data: data!, encoding: NSASCIIStringEncoding)
                if(statusCode == 200 || statusCode == 201 && result == "true") {
                    // Success
                    let statusCode = (response as! NSHTTPURLResponse).statusCode
                    print("URL DELETE Session Task Succeeded: HTTP \(statusCode)")
                    self.printToMainThread(self.viewController!.STATUS, message: "URL DELETE Session Task Succeeded: HTTP \(statusCode)");
                } else {
                    print("URL DELETE Unexpected Status: HTTP \(statusCode), \(result)")
                    self.printToMainThread(self.viewController!.STATUS, message: "URL DELETE Unexpected Status: HTTP \(statusCode), \(result)");
                }
            }
            else {
                // Failure
                print("URL Session DELETE Task Failed: %@", error!.localizedDescription);
                self.printToMainThread(self.viewController!.STATUS, message: "URL DELETE Session Task Failed: \(error!.localizedDescription)")
            }
        })
        task.resume()
    }
    
    func printToMainThread(textField:UITextField, message:String) {
        dispatch_async(dispatch_get_main_queue(), {
            textField.text = message
        })
    }
}