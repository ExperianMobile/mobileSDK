
//  AppDelegate.swift
//  PushApi
//
//  Created by Stephen Benelisha on 10/7/15.
//  Copyright © 2015 experian. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var viewController = ViewController()
    var ems:EMS?
    
    //  CHANGE THESE VALUES YOUR ACCOUNT PREFERENCES
    let custId = "100"
    let appId = "98dd6dbb-8d0b-4450-91ed-85ce46e5febb"
    let hostName = "cs.sbox.eccmp.com"
    var tokenString:String = ""
    var prid:String = ""

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        print("Requesting APN Device Id.")
        viewController = getViewController()
        ems = EMS(view: viewController, tokenStr: tokenString)
        // Override point for customization after application launch.
        let type: UIUserNotificationType = [UIUserNotificationType.Badge, UIUserNotificationType.Alert, UIUserNotificationType.Sound];
        let setting = UIUserNotificationSettings(forTypes: type, categories: nil);
        UIApplication.sharedApplication().registerUserNotificationSettings(setting);
        UIApplication.sharedApplication().registerForRemoteNotifications();
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        if(ems!.prid.characters.count > 0) {
            ems!.GET()
        }
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        ems!.DELETE()
    }
    
    func application(application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: NSData) {
        print("Successfully got APN device ID! \(deviceToken)")
        
        //HTTP escape apn token
        let tokenChars = UnsafePointer<CChar>(deviceToken.bytes)
        self.tokenString = ""
        for var i = 0; i < deviceToken.length; i++ {
            self.tokenString += String(format: "%02.2hhx", arguments: [tokenChars[i]])
        }
        ems = EMS(view: viewController, tokenStr: tokenString)
        ems!.printToMainThread(self.viewController.APN, message: self.tokenString)
        
        ems!.POST()
    }
    
    func application(application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: NSError) {
        // Running as simulator?, create sample APN string
        #if (arch(i386) || arch(x86_64)) && os(iOS)
            self.tokenString =
            "fc7815eccb1acc401598cab834149113c138d4c5c52abe345e1798621283ae14"
            ems = EMS(view: viewController, tokenStr: tokenString)
            ems!.printToMainThread(self.viewController.STATUS, message: "Running as simulator")
            ems!.printToMainThread(self.viewController.APN, message: self.tokenString)
            ems!.POST()
        #else
            print("Failed to get APN device ID \(error)")
            self.printToMainThread(self.viewController.PRID, message: "Failed to get APN device ID \(error)")
        #endif
    }
    
    func getViewController() -> ViewController {
        var ret:ViewController!
        if let viewController = self.window?.rootViewController as? ViewController{
            ret = viewController
        }
        return ret
    }
}

