//
//  ViewController.swift
//  PushApi
//
//  Created by Stephen Benelisha on 10/7/15.
//  Copyright © 2015 experian. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    
    var ems:EMS?

    @IBOutlet weak var APN: UITextField!
    @IBOutlet weak var PRID: UITextField!
    @IBOutlet weak var STATUS: UITextField!
    
    @IBOutlet var VERSION: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ems = EMS(view: self)
        VERSION.text = ["V", NSBundle.mainBundle().infoDictionary?["CFBundleShortVersionString"] as! String].joinWithSeparator(" ")
        
        // Do any additional setup after loading the view, typically from a nib.
        
        // Set up APN UiTextField so that it can be edited
        APN.returnKeyType = UIReturnKeyType.Done
        APN.clearButtonMode =  UITextFieldViewMode.WhileEditing
        APN.delegate = self

        STATUS.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func ChangeToApn(sender: UITextField) {
        ems?.PUT(sender.text!)
    }
    
    
    @IBAction func GET(sender: UIButton) {
        let alert = UIAlertController(title: "GET", message: "To execute a GET, put this App in the background and then bring it back into the foreground, this will cause a GET to be called", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Close", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    @IBAction func POST(sender: UIButton) {
        ems?.tokenString = self.APN.text!
        ems?.POST()
    }
    
    @IBAction func PUT(sender: UIButton) {
        let alert = UIAlertController(title: "PUT", message: "To execute a PUT, click on the 'Prid' Textfield and change the value. Then Press 'DONE' on the keyboard", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Close", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    @IBAction func DELETE(sender: UIButton) {
        ems?.tokenString = self.APN.text!
        ems?.DELETE()
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        var ret = true
        if(textField == STATUS) {
            ret = false
        }
        return ret
    }

}

