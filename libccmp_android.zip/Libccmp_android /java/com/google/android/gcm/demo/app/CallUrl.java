package com.google.android.gcm.demo.app;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;

/**
 * Created by cegalec on 11/06/2015.
 */
public class CallUrl extends AsyncTask<String, Void, String> {
    @Override
    protected void onPreExecute() {
    }
    @Override
    protected void onPostExecute(String result) {
    }
    protected String doInBackground(String...getUrl) {

        try {
            HttpClient client = new DefaultHttpClient();
            HttpGet get = new HttpGet(getUrl[0]);
            HttpResponse responseGet = client.execute(get);
            HttpEntity resEntityGet = responseGet.getEntity();
            if (resEntityGet != null) {
                // do something with the response
                String response = EntityUtils.toString(resEntityGet);
                Log.d("GET RESPONSE", response);
            }
            return "";
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}
