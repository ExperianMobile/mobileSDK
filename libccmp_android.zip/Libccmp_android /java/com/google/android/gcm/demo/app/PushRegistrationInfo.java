package com.google.android.gcm.demo.app;

public class PushRegistrationInfo {
    private String gcmRegId = "";
    private String idClient = "";
    private String idApplication = "";

    public void setgcmRegId(String gcmRegId)
    {
        this.gcmRegId = gcmRegId;
    }

    public String getgcmRegId()
    {
        return this.gcmRegId;
    }

    public void setidClient(String Entity)
    {
        this.idClient = idClient;
    }

    public String getidClient()
    {
        return this.idClient;
    }

    public void setidApplication(String idApplication)
    {
        this.idApplication = idApplication;
    }

    public String getidApplication()
    {
        return this.idApplication;
    }
}
