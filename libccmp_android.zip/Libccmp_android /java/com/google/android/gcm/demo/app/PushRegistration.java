package com.google.android.gcm.demo.app;

/**
 * Created by dehhugu on 23/01/2015.
 */
public class PushRegistration {
    private PushOperatingSystem OperatingSystem = null;
    private String Entity = "";
    private String FieldName = "";
    private String PKName = "";
    private String PKValue = "";
    public PushRegistrationInfo PushRegistrationInformations = null;

    public void setPushOperatingSystem(PushOperatingSystem OperatingSystem)
    {
        this.OperatingSystem = OperatingSystem;
    }

    public PushOperatingSystem getPushOperatingSystem()
    {
        return this.OperatingSystem;
    }

    public void setEntity(String Entity)
    {
        this.Entity = Entity;
    }

    public String getEntity()
    {
        return this.Entity;
    }

    public void setFieldName(String FieldName)
    {
        this.FieldName = FieldName;
    }

    public String getFieldName()
    {
        return this.FieldName;
    }

    public void setPKName(String PKName)
    {
        this.PKName = PKName;
    }

    public String getPKName()
    {
        return this.PKName;
    }

    public void setPKValue(String PKValue)
    {
        this.PKValue = PKValue;
    }

    public String getPKValue()
    {
        return this.PKValue;
    }

}
