package com.google.android.gcm.demo.app;

/**
 * Created by cegalec on 03/06/2015.
 */
public class RegistrationPush {

    private String CustId = "";
    private String AppId = "";
    private String DeviceToken = "";

    public RegistrationPush(String custId,String appId,String deviceToken)
    {
        CustId = custId;
        AppId = appId;
        DeviceToken = deviceToken;
    }
}