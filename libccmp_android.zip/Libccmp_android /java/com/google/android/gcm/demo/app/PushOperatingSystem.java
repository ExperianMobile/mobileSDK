package com.google.android.gcm.demo.app;

/**
 * Created by dehhugu on 26/01/2015.
 */
public enum PushOperatingSystem {
    IOS(100),
    GCM(200),
    WEB(400),
    WP(800);

    private final int value;

    private PushOperatingSystem(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }
};
