/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.android.gcm.demo.app;

import com.google.android.gms.gcm.GoogleCloudMessaging;

import com.example.cegalec.librarypush.*;

import android.app.Activity;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.renderscript.RenderScript;
import android.support.v4.app.NotificationCompat;
import android.transition.Visibility;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.lang.String;

/**
 * This {@code IntentService} does the actual handling of the GCM message.
 * {@code GcmBroadcastReceiver} (a {@code WakefulBroadcastReceiver}) holds a
 * partial wake lock for this service while the service does its work. When the
 * service is finished, it calls {@code completeWakefulIntent()} to release the
 * wake lock.
 */
public class GcmIntentService extends IntentService {
    public static final int NOTIFICATION_ID = 1;
    private NotificationManager mNotificationManager;
    NotificationCompat.Builder builder;

    public GcmIntentService() {
        super("GcmIntentService");
    }
    public static final String TAG = "GCM Demo";

    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(this);
        // The getMessageType() intent parameter must be the intent you received
        // in your BroadcastReceiver.
        String messageType = gcm.getMessageType(intent);

        if (!extras.isEmpty()) {  // has effect of unparcelling Bundle
            /*
             * Filter messages based on message type. Since it is likely that GCM will be
             * extended in the future with new message types, just ignore any message types you're
             * not interested in, or that you don't recognize.
             */
            if (GoogleCloudMessaging.MESSAGE_TYPE_SEND_ERROR.equals(messageType)) {
                sendNotification(extras);
            } else if (GoogleCloudMessaging.MESSAGE_TYPE_DELETED.equals(messageType)) {
                sendNotification(extras);
                // If it's a regular GCM message, do some work.
            } else if (GoogleCloudMessaging.MESSAGE_TYPE_MESSAGE.equals(messageType)) {
                // This loop represents the service doing some work.
                for (int i = 0; i < 4; i++) {
                    Log.i(TAG, "Working... " + (i + 1)
                            + "/5 @ " + SystemClock.elapsedRealtime());
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                    }
                }
                Log.i(TAG, "Completed work @ " + SystemClock.elapsedRealtime());
                // Post notification of received message.
                sendNotification(extras);
                   Log.i(TAG, "Received: " + extras.toString());
            }
        }
        // Release the wake lock provided by the WakefulBroadcastReceiver.
        GcmBroadcastReceiver.completeWakefulIntent(intent);
    }

    // Put the message into a notification and post it.
    // This is just one simple example of what you might choose to do with
    // a GCM message.
    private void sendNotification(Bundle extras) {

        JSONObject mainObject = null;

        // classic notification

        //String text = extras.getString("text");
        //Integer badge = Integer.parseInt(extras.getString("badge"));
        String body = extras.getString("body");
        String sound = extras.getString("sound");
        String title = extras.getString("title");
        String ems_url = extras.getString("ems_url");

        /*
        Uri uri = Uri.parse("http://www.google.com"); // missing 'http://' will cause crashed
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
        */

        //String alert = extras.getString("alert");
        //String message = extras.getString("message");

        // parse the body param and call the url GET
        //Uri.Parse(body);


        boolean autoCancel = extras.getBoolean("autocancel");

        // get from url
        //Bitmap largeIcon = getBitmapFromURL(extras.getString("largeicon"));
        //"http://www.mybuys.com/wp-content/uploads/grid-logo-experian.png"

        //get in local
        Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.experianlogo);

        mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);

        Intent notificationIntent = new Intent(getApplicationContext(), MainActivity.class);

        notificationIntent.putExtra("extrasPush", extras);

        notificationIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_SINGLE_TOP |
                Intent.FLAG_ACTIVITY_NEW_TASK);

        //define action after click on push notification
        PendingIntent contentIntent = PendingIntent.getActivity(getApplicationContext(), 0,
                notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        //Uri alarmSound = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.siren);

        //Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        // Uri alarmSound = Uri.parse("uri://sadfasdfasdf.mp3");
        //String packageName = "GcmClient";

        String packageName = "com.google.android.gcm.demo.app";
        Uri alarmSound = Uri.parse("android.resource://" + packageName + "/" + R.raw.r2d2sms);

        long[] vibrate = { 1000, 1000, 1000, 1000 };

        NotificationCompat.Builder mBuilder =
               new NotificationCompat.Builder(this)
                            .setSmallIcon(R.drawable.experianlogo)
                            //.setNumber(badge)
                            .setContentTitle(title)
                            .setContentText(body)
                            .setLargeIcon(largeIcon)
                            .setAutoCancel(autoCancel)
                            .setCategory("CATEGORY_PROMO")
                            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                            .setPriority(Notification.PRIORITY_MAX)
                            //.setSound(alarmSound)
                            .setVibrate(vibrate)
                            .setLights(Color.RED, 100, 0)
                            .setStyle(new NotificationCompat.BigTextStyle()
                               .bigText(body))
                        .setDefaults(NotificationCompat.DEFAULT_SOUND);

        mBuilder.setContentIntent(contentIntent);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());


        // library

/*
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, DemoActivity.class), 0);

        LibraryPush libraryPush = new LibraryPush();
        String test = LibraryPush.TestMethodLibrary();

        libraryPush.BasicNotification(contentIntent,this, R.drawable.experianlogo);

        // basic notification
        this.BasicNotification();
*/
        // big text style notification

        //this.BigTextStyleNotification();

        // big picture style notification
        //this.BigPictureStyleNotification();

        // inbox style notification
        //this.InboxStyleNotification();

        // inbox style notification
        //this.InboxStyleNotification();

        //this.ActionNotification();
    }

    public void BasicNotification()
    {
        //Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.experianlogo);

        mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, DemoActivity.class), 0);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this)
                .setContentTitle("Basic Notification")
                .setContentText("Basic Notification content")
                .setSmallIcon(R.drawable.experianlogo)
                .setAutoCancel(true);

        mBuilder.setContentIntent(contentIntent);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
    }

    public void BigTextStyleNotification()
    {
        mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, DemoActivity.class), 0);

        String msgText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this)
                .setContentTitle("Big text Notification Title")
                .setContentText("Big text Notification Content")
                .setSmallIcon(R.drawable.experianlogo)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(msgText));

        mBuilder.setContentIntent(contentIntent);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
    }

    public void BigPictureStyleNotification()
    {

        // get from url
        Bitmap largeIcon = getBitmapFromURL("http://www.mybuys.com/wp-content/uploads/grid-logo-experian.png");


        mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, DemoActivity.class), 0);

        //NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        Notification.Builder mBuilder = new Notification.Builder(this);

        mBuilder.setContentTitle("Big picture Notification")
                .setContentText("Big picture Notification content")
                .setSmallIcon(R.drawable.experianlogo);

        // Now create the Big picture notification.
        Notification notification = new Notification.BigPictureStyle(mBuilder)
                .bigPicture(largeIcon).build();

        // Put the auto cancel notification flag
        notification.flags |= Notification.FLAG_AUTO_CANCEL;

        mBuilder.setContentIntent(contentIntent);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());

        /*
                PendingIntent pi = getPendingIntent();
                Builder builder = new Notification.Builder(this);
                builder.setContentTitle("BP notification")
                        // Notification title
                        .setContentText("BigPicutre notification")
                                // you can put subject line.
                        .setSmallIcon(R.drawable.ic_launcher)
                                // Set your notification icon here.
                        .addAction(R.drawable.ic_launcher_web, "show activity", pi)
                        .addAction(
                                R.drawable.ic_launcher_share,
                                "Share",
                                PendingIntent.getActivity(getApplicationContext(), 0,
                                        getIntent(), 0, null));

                // Now create the Big picture notification.
                Notification notification = new Notification.BigPictureStyle(builder)
                        .bigPicture(
                                BitmapFactory.decodeResource(getResources(),
                                        R.drawable.big_picture)).build();
                // Put the auto cancel notification flag
                notification.flags |= Notification.FLAG_AUTO_CANCEL;
                NotificationManager notificationManager = getNotificationManager();
                notificationManager.notify(0, notification);
        */
    }


    public void BigPictureStyleNotificationWithAction()
    {
        // get from url
        Bitmap largeIcon = getBitmapFromURL("http://www.mybuys.com/wp-content/uploads/grid-logo-experian.png");

        mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, DemoActivity.class), 0);

        //NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        Notification.Builder mBuilder = new Notification.Builder(this);

        Intent in=new Intent(getApplicationContext(), DemoActivity.class);

        mBuilder.setContentTitle("Big picture Notification")
                .setContentText("Big picture Notification content")
                .setSmallIcon(R.drawable.experianlogo)
                // Set your notification icon here.
                .addAction(R.drawable.experianlogo, "show activity", contentIntent);


        /*
                    .addAction(
                            R.drawable.experianlogo,
                            "Share",
                            PendingIntent.getActivity(getApplicationContext(), 0,
                                    in, 0, null));
        */

        // Now create the Big picture notification.
        Notification notification = new Notification.BigPictureStyle(mBuilder)
                .bigPicture(largeIcon).build();

        // Put the auto cancel notification flag
        notification.flags |= Notification.FLAG_AUTO_CANCEL;

        mBuilder.setContentIntent(contentIntent);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());

    }

    public void InboxStyleNotification()
    {
        Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.experianlogo);

        PendingIntent pi = getPendingIntent();
        Notification.Builder builder = new Notification.Builder(this)
                .setContentTitle("Inbox style Notification")
                .setContentText("Inbox Style notification!!")
                .setSmallIcon(R.drawable.experianlogo);

        Notification notification = new Notification.InboxStyle(builder)
                .addLine("First message").addLine("Second message")
                .addLine("Thrid message").addLine("Fourth Message")
                .setSummaryText("+2 more").build();
        // Put the auto cancel notification flag
        notification.flags |= Notification.FLAG_AUTO_CANCEL;
        NotificationManager notificationManager = getNotificationManager();
        notificationManager.notify(0, notification);
    }

    public void ActionNotification()
    {
        Intent intent = new Intent(this, DemoActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, DemoActivity.class), 0);

        Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.experianlogo);

        {
            Notification.Builder builder = new Notification.Builder(this);
            builder.setSmallIcon(R.drawable.ic_launcher);
            builder.setTicker("3 new messages ");
            builder.setContentTitle("3 new messages");
            builder.setContentText("+ 5 more");
            builder.setSubText("Click here to go to inbox.");
            builder.setLargeIcon(largeIcon);
            builder.setAutoCancel(true);
            builder.addAction(android.R.drawable.sym_action_email,"Do something", contentIntent);
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(00, builder.build());
        }

    }

    public PendingIntent getPendingIntent() {
        return PendingIntent.getActivity(this, 0, new Intent(this,
                DemoActivity.class), 0);
    }

    public NotificationManager getNotificationManager() {
        return (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    public Bitmap getBitmapFromURL(String strURL) {
        try {
            URL url = new URL(strURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

/*    public static String[] extractLinks(String text) {
        List<String> links = new ArrayList<String>();
        Matcher m = Patterns.WEB_URL.matcher(text);
        while (m.find()) {
            String url = m.group();
            Log.d(TAG, "URL extracted: " + url);
            links.add(url);
        }

        return links.toArray(new String[links.size()]);
    }*/
}
