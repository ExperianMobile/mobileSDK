package com.google.android.gcm.demo.app;


import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.view.View.OnClickListener;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.json.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.experian.ccmp.OauthConfig;
import com.experian.ccmp.SearchQuery;
import com.experian.ccmp.CustomerConfig;
import com.experian.ccmp.ICallBack;
import com.experian.ccmp.Push;
import java.util.TimeZone;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;

public class MainActivity extends ActionBarActivity {

    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    public static final String PROPERTY_REG_ID = "registration_id";
    private static final String PROPERTY_APP_VERSION = "appVersion";

    private static final String TAG = MainActivity.class.getSimpleName(); // for log

    GoogleCloudMessaging gcm;
    Context context;

    String custId;
    String appId;
    String ipCcmp;
    String deviceToken;
    String pushRegId;
    String returnedValue;
    String key;
    String pass;
    String formId;
    boolean firstRun;
    String idColumnName;
    String idColumnValue;
    String updateColumnName;
    String accessToken;
    String tableName;
    String viewId;

    Button btRegistration = null;
    Button btGetNewRegid = null;
    Button btRegistrationError = null;
    Button btUpdateRegId = null;
    Button btDeleteRegId = null;
    Button btAction = null;
    Button btSearchRecord = null;
    Button btGetAuthToken = null;
    Button btGetRecord = null;

    EditText etCustId = null;
    EditText etAppId = null;
    EditText etDeviceToken = null;
    EditText etIp = null;
    EditText etKey = null;
    EditText etPass = null;
    EditText etAccessToken = null;
    EditText etReturnValue = null;
    EditText etPushRegId = null;
    EditText etFormId = null;
    EditText etIdColumnName = null;
    EditText etIdColumnValue = null;
    EditText etUpdateColumnName = null;
    EditText etTableName = null;
    EditText etViewId = null;

    TextView tvInfosCall = null;
    TextView tvError = null;

   // Spinner spinnerAction = null;

    RadioButton radioSearchRecordOperation = null;
    RadioButton radioSearchRecordTableName = null;
    RadioButton radioGetRecordsRecordId = null;
    RadioButton radioGetRecordsTableName = null;

    //default value sandbox
    /*String defaultCustId = "126";
    String defaultAppId = "f45d8d16-4c1a-41cb-b087-de303a7ec84f";
    String defaultDeviceToken = "Foo1";
    String defaultIp = "http://cs.sbox.eccmp.com";
    String defaultPushRegistrationId = "";
    String defaultReturnedValue = "";
    String defaultFormId = "17";
    String defaultKey = "MTI2OjEwMA==";
    String defaultPass = "281f677b6fa54f2f8ae53b95afce9741";
    String defaultIdColumnName = "email";
    String defaultIdColumnValue = "j";
    String defaultUpdateColumnName = "email";
    String defaultTableName = "test%20contact";
    String defaultAccessToken = "AAEAALcQqCFoOfq0n3sBA9xrSOJ55aVJUZQLkcXKgc-v7XpDiKyEy4Fuhn8zLnTkGjgD-efi1xJQKsXKZumGNE4OQ6IB__IgFwtF9Hz1tkIfB_pT_YoLGeTbCgPWBAJqOe3nCkMfKVPvPERpB9G7jUmAdINjmpP5utHVGKY67QL1mruktHQGNkOX-mo2jxnGSsXL1_T8WtxrCYgw6Lwek8OsuuHvWTLoN6Rc9_FbeSkf0PhfFa0OFnbJlDG6stUwSe1tKNnNjYSTvXrbERbgoJXgyTW1L1xUSwH8-sphH7hfdVlizS31uSbAItPjV_CwAtP_Jxtfv4UVH7ZbZ1Mi2mCaLYdkAQAAAAEAAGkESy-SjFuFbpbY4lWunahUalgq41s7_SydW-2w1q8GN9i6MIY51bsF5tci1CtIpqbXkZotpI5wIPajNrxDm7cr3v-EjEfVzqqCkA16_k4wQNDdO2sgEdfRvJVssvTPR35N79HZS7rZ-Ggn1EqTbsfm8zJX2NtRohaH7k7-2mur1iYneeJphUAhEE-45-FZInaSM_vvBAcJRSqanZ7gQvbIwrvQKdD18iQofbv0njZOMuJW7s4DGELUbEzw7_1o1hGbXdW-VG-byiwxPREQtyqFhjFVcb5O-G-Zlnx06-A_RCLXWe7UTu7qXrPwJai8R8nkj7ms2J1mv4_C5r1QGXYClN6mpoCnxxyGEciIbiE6EX6JqdwDyDdwIceglZi4HNhj_1QzWssix5xpS0aKN4gEsbrgdi0g8P59IWeW95K6k7GAMzMLJUyUSAEDXAD4vd89KtA84E9FrznGNcF1mCQ";
    String defaultViewId = "1017";*/


    //default value QA
    String defaultCustId = "126";
    String defaultAppId = "36f97e7a-9fde-4be2-a77e-aa977ff53dd6";
    String defaultDeviceToken = "Foo1";
    String defaultIp = "http://10.24.16.71";
    String defaultPushRegistrationId = "";
    String defaultReturnedValue = "";
    String defaultFormId = "17";
    String defaultKey = "MTQyODE6MTAw";
    String defaultPass = "300d11f20c494ebabb510bb0b5ecb204";
    String defaultIdColumnName = "email";
    String defaultIdColumnValue = "j";
    String defaultUpdateColumnName = "email";
    String defaultTableName = "test%20contact";
    String defaultAccessToken = "AAEAALcQqCFoOfq0n3sBA9xrSOJ55aVJUZQLkcXKgc-v7XpDiKyEy4Fuhn8zLnTkGjgD-efi1xJQKsXKZumGNE4OQ6IB__IgFwtF9Hz1tkIfB_pT_YoLGeTbCgPWBAJqOe3nCkMfKVPvPERpB9G7jUmAdINjmpP5utHVGKY67QL1mruktHQGNkOX-mo2jxnGSsXL1_T8WtxrCYgw6Lwek8OsuuHvWTLoN6Rc9_FbeSkf0PhfFa0OFnbJlDG6stUwSe1tKNnNjYSTvXrbERbgoJXgyTW1L1xUSwH8-sphH7hfdVlizS31uSbAItPjV_CwAtP_Jxtfv4UVH7ZbZ1Mi2mCaLYdkAQAAAAEAAGkESy-SjFuFbpbY4lWunahUalgq41s7_SydW-2w1q8GN9i6MIY51bsF5tci1CtIpqbXkZotpI5wIPajNrxDm7cr3v-EjEfVzqqCkA16_k4wQNDdO2sgEdfRvJVssvTPR35N79HZS7rZ-Ggn1EqTbsfm8zJX2NtRohaH7k7-2mur1iYneeJphUAhEE-45-FZInaSM_vvBAcJRSqanZ7gQvbIwrvQKdD18iQofbv0njZOMuJW7s4DGELUbEzw7_1o1hGbXdW-VG-byiwxPREQtyqFhjFVcb5O-G-Zlnx06-A_RCLXWe7UTu7qXrPwJai8R8nkj7ms2J1mv4_C5r1QGXYClN6mpoCnxxyGEciIbiE6EX6JqdwDyDdwIceglZi4HNhj_1QzWssix5xpS0aKN4gEsbrgdi0g8P59IWeW95K6k7GAMzMLJUyUSAEDXAD4vd89KtA84E9FrznGNcF1mCQ";
    String defaultViewId = "1481";

    int currentTimeZone=-1;
    //Calendar token_expiration=  Calendar.getInstance();

    String lastException = "";
    CustomerConfig config;
    OauthConfig oauthConfig;
    SearchQuery query;

    private String[] arrActionsNames  = {"Button click","Time in app","form submission","page view","link clicked"};
    HashMap<String, Integer> hashActions;

    /**
     * Substitute you own sender ID here. This is the project number you got
     * from the API Console, as described in "Getting Started."
     */
    String SENDER_ID = "916294568312";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        context = getApplicationContext();

        // define properties button/edittext
        btRegistration = (Button)findViewById(R.id.btRegistration);
        btGetNewRegid = (Button)findViewById(R.id.btGetNewRegid);
        btRegistrationError = (Button)findViewById(R.id.btRegistrationError);
        btUpdateRegId = (Button)findViewById(R.id.btUpdateRegId);
        btDeleteRegId = (Button)findViewById(R.id.btDeleteRegId);
        btAction = (Button)findViewById(R.id.btAction);
        btSearchRecord = (Button)findViewById(R.id.btSearchRecord);
        btGetAuthToken = (Button)findViewById(R.id.btGetAuthToken);
        btGetRecord = (Button)findViewById(R.id.btGetRecord);

        etCustId = (EditText)findViewById(R.id.etCustId);
        etAppId = (EditText)findViewById(R.id.etAppId);
        etDeviceToken = (EditText)findViewById(R.id.etDeviceToken);
        etIp =  (EditText)findViewById(R.id.etIp);
        etReturnValue = (EditText)findViewById(R.id.etReturnValue);
        etPushRegId = (EditText)findViewById(R.id.etPushRegId);
        etKey = (EditText)findViewById(R.id.etKey);
        etPass = (EditText)findViewById(R.id.etPass);
        etAccessToken = (EditText)findViewById(R.id.etAccessToken);
        etFormId = (EditText)findViewById(R.id.etFormId);
      //  spinnerAction = (Spinner)findViewById(R.id.spinnerAction);
        etIdColumnName = (EditText)findViewById(R.id.etIdColumnName);
        etIdColumnValue = (EditText)findViewById(R.id.etIdColumnValue);
        etUpdateColumnName = (EditText)findViewById(R.id.etUpdateColumnName);
        etTableName = (EditText)findViewById(R.id.etTableName);
        etViewId = (EditText)findViewById(R.id.etViewId);

        radioSearchRecordOperation = (RadioButton)findViewById(R.id.radioSearchRecordOperation);
        radioSearchRecordTableName = (RadioButton)findViewById(R.id.radioSearchRecordTableName);
        radioGetRecordsRecordId = (RadioButton)findViewById(R.id.radioGetRecordsRecordId);
        radioGetRecordsTableName = (RadioButton)findViewById(R.id.radioGetRecordsTableName);

        // set events onclick
        btRegistration.setOnClickListener(registrationListener);
        btGetNewRegid.setOnClickListener(getNewRegidListener);
        btRegistrationError.setOnClickListener(registrationErrorListener);
        btUpdateRegId.setOnClickListener(updateRegIdListener);
        btDeleteRegId.setOnClickListener(deleteRegIdListener);
        btAction.setOnClickListener(actionListener);
        btSearchRecord.setOnClickListener(searchRecordListener);
        btGetAuthToken.setOnClickListener(getAuthTokenListener);
        btGetRecord.setOnClickListener(getRecordListener);

        //get shared preferences
        SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
        custId = settings.getString("preference_cust_id", defaultCustId);
        Log.d(TAG, "custid sharedpreferences value :" + custId);

        appId = settings.getString("preference_app_id", defaultAppId);
        Log.d(TAG, "appid sharedpreferences value :" + appId);

        ipCcmp = settings.getString("preference_ip_ccmp", defaultIp);
        Log.d(TAG, "ip sharedpreferences value :" + ipCcmp);

        deviceToken = settings.getString("preference_device_token", defaultDeviceToken);
        Log.d(TAG, "devicetoken sharedpreferences value :" + deviceToken);

        pushRegId = settings.getString("preference_push_reg_id", defaultPushRegistrationId);
        Log.d(TAG, "pushRegId sharedpreferences value :" + pushRegId);

        returnedValue = settings.getString("preference_return_value", defaultReturnedValue);
        Log.d(TAG, "returnedValue sharedpreferences value :" + returnedValue);

        firstRun = settings.getBoolean("preference_first_run", true);
        Log.d(TAG, "firstRun sharedpreferences value :" + firstRun);

        key = settings.getString("preference_key", defaultKey);
        Log.d(TAG, "key sharedpreferences value :" + key);

       // this make the application buggy - this logic need to change
        pass = "300d11f20c494ebabb510bb0b5ecb204";
        Log.d(TAG, "pass sharedpreferences value :" + pass);

        accessToken = settings.getString("preference_access_token", defaultAccessToken);
        Log.d(TAG, "access token sharedpreferences value :" + accessToken);

        formId = settings.getString("preference_form_id", defaultFormId);
        Log.d(TAG, "formId sharedpreferences value :" + formId);

        idColumnName = settings.getString("preference_id_column_name", defaultIdColumnName);
        Log.d(TAG, "idColumnName sharedpreferences value :" + idColumnName);

        idColumnValue = settings.getString("preference_id_column_value", defaultIdColumnValue);
        Log.d(TAG, "idColumnValue sharedpreferences value :" + idColumnValue);

        updateColumnName = settings.getString("preference_update_column_name", defaultUpdateColumnName);
        Log.d(TAG, "updateColumnName sharedpreferences value :" + updateColumnName);

        tableName = settings.getString("preference_table_name", defaultTableName);
        Log.d(TAG, "tableName sharedpreferences value :" + tableName);

        viewId = settings.getString("preference_view_id", defaultViewId);
        Log.d(TAG, "view id sharedpreferences value :" + viewId);

        //added by dtk
        Calendar mCalendar = new GregorianCalendar();
        TimeZone mTimeZone = mCalendar.getTimeZone();
        int mGMTOffset =mTimeZone.getRawOffset();
        long test=TimeUnit.MILLISECONDS.convert(mGMTOffset,TimeUnit.MILLISECONDS);

        //SimpleDateFormat formatter=new SimpleDateFormat("DD-MMM-yyyy");
        //token_expiration = settings.getString("preference_token_expiration", formatter.format(test));

        Log.d(TAG, "preference_expiration_token" + viewId);

        etCustId.setText(custId);
        etAppId.setText(appId);
        etDeviceToken.setText(deviceToken);
        etIp.setText(ipCcmp);
        etPushRegId.setText(pushRegId);
        etReturnValue.setText(returnedValue);
        etKey.setText(key);
        etPass.setText(defaultPass);
        etAccessToken.setText(accessToken);
        etFormId.setText(formId);
        etIdColumnName.setText(idColumnName);
        etIdColumnValue.setText(idColumnValue);
        etUpdateColumnName.setText(updateColumnName);
        etTableName.setText(tableName);
        etViewId.setText(viewId);

        // set spinner values
        this.setSpinnerContent(arrActionsNames);

        // set config params object
        SetConfigParams();

        if(firstRun)
        {
            Log.d(TAG, "First run ");
            // intent for listener push notification
            onNewIntent(getIntent());

            // define properties, listener, sharedpreferences on firstlaunch
            this.firstRunMethod();

            //this.setSpinnerContent(arrActionsNames);
            setTitle("Ems Reference app");
        }

        this.AddListenerEditText();

        Log.d(TAG, "Before save shared preferences ");
        this.SaveSharedPreferences();

    }

    private void setSpinnerContent(String arrActions[]){
        String arrNewArray[]    = new String[arrActions.length];

        hashActions = new HashMap<String, Integer>();
        int i=0;
        // set spinner hashtable values
        for(String actionString : arrActionsNames)
        {
            hashActions.put(actionString,i);
            i = i+1;
        }

        for(int j=0; j < arrActions.length; j++){
            arrNewArray[j]    = arrActions[j];
        }

        //Application of the Array to the Spinner
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                arrNewArray
        );
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      //  spinnerAction.setAdapter(spinnerArrayAdapter);
    }

    private void AddListenerEditText()
    {
        //add change listener for editText

        //cust id
        etCustId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_cust_id", etCustId.getText().toString());
                editor.apply();
                custId = etCustId.getText().toString();
            }
        });

        //app id
        etAppId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_app_id", etAppId.getText().toString());
                editor.apply();

                appId = etAppId.getText().toString();
            }
        });

        //IP
        etIp.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_ip_ccmp", etIp.getText().toString());
                editor.apply();

                ipCcmp = etIp.getText().toString();
            }
        });

        //device token
        etDeviceToken.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_device_token", etDeviceToken.getText().toString());
                editor.apply();

                deviceToken = etDeviceToken.getText().toString();
            }
        });

        //push reg id
        etPushRegId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_push_reg_id", etPushRegId.getText().toString());
                editor.apply();

                pushRegId = etPushRegId.getText().toString();
            }
        });

        //return value
        etReturnValue.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_return_value", etReturnValue.getText().toString());
                editor.apply();

                returnedValue = etReturnValue.getText().toString();
            }
        });

        //key
        etKey.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_key", etKey.getText().toString());
                editor.apply();

                key = etKey.getText().toString();
            }
        });

        //pass
        etPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_pass", etPass.getText().toString());
                editor.apply();

                pass = etPass.getText().toString();
            }
        });

        //formid
        etFormId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_form_id", etFormId.getText().toString());
                editor.apply();

                formId = etFormId.getText().toString();
            }
        });

        //idColumnName
        etIdColumnName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_id_column_name", etIdColumnName.getText().toString());
                editor.apply();

                idColumnName = etIdColumnName.getText().toString();
            }
        });

        //idColumnValue
        etIdColumnValue.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_id_column_value", etIdColumnValue.getText().toString());
                editor.apply();

                idColumnValue = etIdColumnValue.getText().toString();
            }
        });

        //updateColumnName
        etIdColumnValue.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_update_column_name", etUpdateColumnName.getText().toString());
                editor.apply();

                updateColumnName = etUpdateColumnName.getText().toString();
            }
        });

        //tableName
        etIdColumnValue.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_table_name", etTableName.getText().toString());
                editor.apply();

                tableName = etTableName.getText().toString();
            }
        });

        //view id
        etViewId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("preference_view_id", etViewId.getText().toString());
                editor.apply();

                viewId = etViewId.getText().toString();
            }
        });
    }

    private void firstRunMethod()
    {
        Log.d(TAG, "First run method code");

        //get shared preferences
        SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);

        firstRun = false;
        SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean("preference_first_run", false);
        // Apply the edits!
        editor.apply();

        // get New Regid method on first launch
        this.getNewRegid();

    }

    private void SaveSharedPreferences()
    {
        Log.d(TAG, "save shared preferences method : start ");
        SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
        SharedPreferences.Editor editor = settings.edit();
        Log.d(TAG, "cust id ");
        editor.putString("preference_cust_id", etCustId.getText().toString());
        Log.d(TAG, "app id ");
        editor.putString("preference_app_id", etAppId.getText().toString());
        Log.d(TAG, "ip ccmp ");
        editor.putString("preference_ip_ccmp", etIp.getText().toString());
        Log.d(TAG, "device token ");
        editor.putString("preference_device_token", etDeviceToken.getText().toString());
        Log.d(TAG, "reg id ");
        editor.putString("preference_push_reg_id", etPushRegId.getText().toString());
        Log.d(TAG, "return value ");
        editor.putString("preference_return_value", etReturnValue.getText().toString());
        Log.d(TAG, "key ");
        editor.putString("preference_key", etKey.getText().toString());
        Log.d(TAG, "pass ");
        editor.putString("preference_pass", etPass.getText().toString());
        Log.d(TAG, "formId ");
        editor.putString("preference_form_id", etFormId.getText().toString());
        Log.d(TAG, "idColumnName ");
        editor.putString("preference_id_column_name", etIdColumnName.getText().toString());
        Log.d(TAG, "idColumnValue ");
        editor.putString("preference_id_column_value", etIdColumnValue.getText().toString());
        Log.d(TAG, "updateColumnName ");
        editor.putString("preference_update_column_name", etUpdateColumnName.getText().toString());
        Log.d(TAG, "tablename ");
        editor.putString("preference_table_name", etTableName.getText().toString());
        Log.d(TAG, "updateColumnName ");
        editor.putString("preference_view_id", etViewId.getText().toString());
        Log.d(TAG, "save shared preferences method : before apply ");
        // Apply the edits!
        editor.apply();
        Log.d(TAG, "save shared preferences method : after apply ");
    }

    private void getNewRegid()
    {
        // Check device for Play Services APK. If check succeeds, proceed with GCM registration.
        if (checkPlayServices()) {
            gcm = GoogleCloudMessaging.getInstance(context);
            pushRegId = getRegistrationId(context);

            //this.SaveSharedPreferences();

            if (pushRegId.isEmpty()) {
                registerInBackground();
            }
            else
            {
                storeRegistrationId(context, "");
                pushRegId="";
                registerInBackground();
            }

        } else {
            Log.d(TAG, "Error : No valid Google Play Services APK Found");
        }

        if(etDeviceToken.getText().toString() != "")
        {
            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("preference_device_token", etDeviceToken.getText().toString());
            editor.putString("preference_return_value", etReturnValue.getText().toString());

            // Apply the edits!
            editor.apply();
        }


        System.gc();
    }
    private void SetConfigParams()
    {
        custId = etCustId.getText().toString();
        appId = etAppId.getText().toString();
        deviceToken = etDeviceToken.getText().toString();
        pushRegId = etPushRegId.getText().toString();

        config= new CustomerConfig();
        config.appId= etAppId.getText().toString();
        config.custId= etCustId.getText().toString();
        config.token= etDeviceToken.getText().toString();
        config.hostname=etIp.getText().toString();
        config.baseUrl=etIp.getText().toString();
        config.registrationId = etPushRegId.getText().toString();

        oauthConfig = new OauthConfig();
        oauthConfig.client_id="2";
        oauthConfig.username=key;
        oauthConfig.password=pass;
        oauthConfig.grant_type="password";
        oauthConfig.oauth_endpoint="/services2/authorization/oAuth2/token";
        oauthConfig.access_token=accessToken;
        oauthConfig.oauth_hostname= etIp.getText().toString();

        query=  new SearchQuery();
        query.recordId="2";
        query.viewName=defaultTableName;
        query.viewId=defaultViewId;//"1017";
        query.prop= "email%2Cphone_number%2Cfirst_name%2Clast_name%2Cphone_number_sp3_status_id";
        query.columnName=idColumnName;
        query.operation="STARTS";
        query.param=idColumnValue;
    }

    @Override
    public void onResume() {
        super.onResume();  // Always call the superclass method first
        onNewIntent(getIntent());
    }

    @Override
    public void onRestart() {
        super.onRestart();  // Always call the superclass method first
        onNewIntent(getIntent());
    }

    @Override
    public void onNewIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        if (extras != null) {
            if (extras.containsKey("extrasPush")) {
                // extract the extra-data in the Notification
                Bundle extrasPush =(Bundle)extras.get("extrasPush");
                //String body = extrasPush.getString("body");
                String returnValue = "";
                for (String key: extrasPush.keySet())
                {
                    Object value = extrasPush.get(key);
                    returnValue += String.format("%s %s , ", key,
                            value.toString());
                }

                etReturnValue.setText(returnValue);
                Object ems_url = extrasPush.get("ems_url");
                if(!((String) ems_url).isEmpty()) {
                    // call url
                    Uri uri = Uri.parse(ems_url.toString()); // missing 'http://' will cause crashed
                    intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }
            }
        }
    }

    public ArrayList retrieveLinks(String text) {
        ArrayList links = new ArrayList();

        String regex = "\\(?\\b(http://|www[.])[-A-Za-z0-9+&@#/%?=~_()|!:,.;]*[-A-Za-z0-9+&@#/%=~_()|]";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(text);
        while(m.find()) {
            String urlStr = m.group();
            char[] stringArray1 = urlStr.toCharArray();

            if (urlStr.startsWith("(") && urlStr.endsWith(")"))
            {

                char[] stringArray = urlStr.toCharArray();

                char[] newArray = new char[stringArray.length-2];
                System.arraycopy(stringArray, 1, newArray, 0, stringArray.length-2);
                urlStr = new String(newArray);
                Log.d(TAG, "Finally Url : " + newArray.toString());

            }
            Log.d(TAG, "Url : " + urlStr);
            links.add(urlStr);
        }
        return links;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // envoyer infos ->CCMP
    private OnClickListener registrationListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                SetConfigParams();
                Log.d(TAG, "start registration to ccmp");

                ICallBack myCallBack= new ICallBack() {
                    public void mcallback(byte [] message_byte)
                    {
                        String message = new String(message_byte);
                        System.out.println("debug info: "+message_byte);
                        System.out.println("debug info: " + message);
                        returnedValue = message;
                        UpdateEtReturnValue();

                        try {
                           /// new
                            JSONObject jsonObject = new JSONObject(message);
                            Boolean IsError=jsonObject.getJSONObject("request").getBoolean("isError");

                            if (IsError!=true) {
                                String pushRegId = jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").getString("Push_Registration_Id");
                                etPushRegId.setText(pushRegId);
                            }else{
                                returnedValue=jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").getString("message");
                            }
                        }
                        catch(JSONException e)
                        {
                            returnedValue ="Exception when creation of jsonObject : "+ e.toString();
                            System.out.println(returnedValue);
                        }
                    }
                };

                Push objectPush = new Push(myCallBack);
                //this is should return nothing
                objectPush.SaveRegistration(config);

                Log.d(TAG, "end registration to ccmp");

            } catch (Exception e) {
                Log.d(TAG, "Error registration to ccmp", e);
                lastException = e.toString();
                returnedValue = "Error registration to ccmp"+ e.toString();
                UpdateEtReturnValue();
            }
            UpdateEtReturnValue();
            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("preference_push_reg_id", etPushRegId.getText().toString());
            editor.putString("preference_return_value", etReturnValue.getText().toString());

            // Apply the edits!
            editor.apply();

            System.gc();
        }
    };


    // get new regid
    private OnClickListener getNewRegidListener = new OnClickListener() {
        @Override
        public void onClick(View v) {

            // Check device for Play Services APK. If check succeeds, proceed with GCM registration.
            if (checkPlayServices()) {
                gcm = GoogleCloudMessaging.getInstance(context);
                pushRegId = getRegistrationId(context);

                if (pushRegId.isEmpty()) {
                    registerInBackground();
                }
                else
                {
                    storeRegistrationId(context, "");
                    pushRegId="";
                    registerInBackground();
                }
                //sendRegidToCCMP(regid);
            } else {
                Log.d(TAG, "Error : No valid Google Play Services APK Found");
            }

            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("preference_device_token", etDeviceToken.getText().toString());

            // Apply the edits!
            editor.apply();

            System.gc();
        }
    };

    // call put method
    private OnClickListener updateRegIdListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                SetConfigParams();
                Log.d(TAG, "start Update Token to ccmp ( Call to PUT method )");

                ICallBack myCallBack= new ICallBack() {
                    public void mcallback(byte [] message_byte)
                    {
                        String message = new String(message_byte);
                        System.out.println("debug info: "+message_byte);
                        System.out.println("debug info: " + message);
                        returnedValue = message;


                        try {
                            JSONObject jsonObject = new JSONObject(message);
                            Boolean IsError=jsonObject.getJSONObject("request").getBoolean("isError");

                            if (IsError!=true) {
                                String data = jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").toString();
                                returnedValue=data;
                            }else{
                                returnedValue=jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").get("message").toString();
                            }
                        }
                        catch(JSONException e)
                        {
                            returnedValue ="Exception when creation of jsonObject : "+ e.toString();
                            System.out.println(returnedValue);
                        }
                    }
                };

                Push objectPush = new Push(myCallBack);
                objectPush.UpdateRegistration(config);

                Log.d(TAG, "end Update Token to ccmp ( Call to PUT method )");

            } catch (Exception e) {
                Log.d(TAG, "Error Update Token to ccmp ( Call to PUT method )", e);
                lastException = e.toString();

                returnedValue = "Error Update Token to ccmp ( Call to PUT method ):" + lastException;
                UpdateEtReturnValue();
            }
            UpdateEtReturnValue();
            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("preference_push_reg_id", etPushRegId.getText().toString());
            editor.putString("preference_return_value", etReturnValue.getText().toString());

            // Apply the edits!
            editor.apply();

            System.gc();
        }
    };

    private String getRegistrationId(Context context) {
        final SharedPreferences prefs = getGcmPreferences(context);
        String registrationId = prefs.getString(PROPERTY_REG_ID, "");
        if (registrationId.isEmpty()) {
            Log.d(TAG, "Registration not found.");
            return "";
        }
        // Check if app was updated; if so, it must clear the registration ID
        // since the existing regID is not guaranteed to work with the new
        // app version.
        int registeredVersion = prefs.getInt(PROPERTY_APP_VERSION, Integer.MIN_VALUE);
        int currentVersion = getAppVersion(context);
        if (registeredVersion != currentVersion) {
            Log.d(TAG, "App version changed.");
            return "";
        }
        return registrationId;
    }

    private OnClickListener deleteRegIdListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
         try {
                SetConfigParams();
                Log.d(TAG, "start call ccmp");

             ICallBack myCallBack= new ICallBack() {
                 public void mcallback(byte [] message_byte)
                 {
                     String message = new String(message_byte);
                     System.out.println("debug info: "+message_byte);
                     System.out.println("debug info: " + message);
                     returnedValue = message;

                     try {
                         JSONObject jsonObject = new JSONObject(message);
                         Boolean IsError=jsonObject.getJSONObject("request").getBoolean("isError");

                         if (IsError!=true) {

                             Boolean data = jsonObject.getJSONObject("request").getJSONObject("data").getBoolean("content");
                             returnedValue=data==true?"true":"false";
                         }else{
                             returnedValue=jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").get("message").toString();
                         }
                     }
                     catch(JSONException e)
                     {
                         returnedValue ="Exception when creation of jsonObject : "+ e.toString();
                         System.out.println(returnedValue);
                     }

                 }
             };

                 Push objectPush = new Push(myCallBack);
                 //this is should return nothing
                 objectPush.DeleteRegistration(config);

                // End call JSON
                Log.d(TAG, "end call ccmp");

            } catch (Exception e) {
                Log.d(TAG, "Error delete regid to ccmp",e);
                lastException = e.toString();
                returnedValue = "Error delete regid to ccmp :" + lastException;
                UpdateEtReturnValue();
            }
            UpdateEtReturnValue();
            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("preference_return_value", etReturnValue.getText().toString());

            // Apply the edits!
            editor.apply();

            System.gc();
        }
    };

    private OnClickListener actionListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                SetConfigParams();
                Log.d(TAG, "start call action listener");

                ICallBack myCallBack= new ICallBack() {
                    public void mcallback(byte [] message_byte)
                    {
                        String message = new String(message_byte);
                        System.out.println("debug info: "+message_byte);
                        System.out.println("debug info: " + message);
                        returnedValue = message;

                        try {
                            JSONObject jsonObject = new JSONObject(message);
                            Boolean IsError=jsonObject.getJSONObject("request").getBoolean("isError");

                            if (IsError!=true) {
                                String data = jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").toString();
                                returnedValue=data;
                            }else{
                                returnedValue=jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").get("message").toString();
                            }
                        }
                        catch(JSONException e)
                        {
                            returnedValue ="Exception when creation of jsonObject : "+ e.toString();
                            System.out.println(returnedValue);
                            UpdateEtReturnValue();
                        }

                    }
                };

                saveActionBackground();

                // End call JSON
                Log.d(TAG, "end call action listener");

            } catch (Exception e) {
                Log.d(TAG, "Error action listener",e);
                lastException = e.toString();
                returnedValue = "Error send action to ccmp :" + lastException;
                UpdateEtReturnValue();
            }
            UpdateEtReturnValue();

            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("preference_return_value", etReturnValue.getText().toString());

            // Apply the edits!
            editor.apply();

            System.gc();
        }
    };

    private OnClickListener searchRecordListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                SetConfigParams();
                Log.d(TAG, "start call search record listener");

                searchRecordBackground();

                // End call JSON
                Log.d(TAG, "end call search record listener");

            } catch (Exception e) {
                Log.d(TAG, "Error search record listener",e);
                lastException = e.toString();
                returnedValue = "Error search record  :" + lastException;
                UpdateEtReturnValue();
            }

            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("preference_return_value", etReturnValue.getText().toString());

            // Apply the edits!
            editor.apply();

            System.gc();
        }
    };

    private OnClickListener getRecordListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                SetConfigParams();
                Log.d(TAG, "start call get record listener");

                getRecordBackground();

                // End call JSON
                Log.d(TAG, "end call get record listener");

            } catch (Exception e) {
                Log.d(TAG, "Error get record listener",e);
                lastException = e.toString();
                returnedValue = "Error get record  :" + lastException;
                UpdateEtReturnValue();
            }

            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("preference_return_value", etReturnValue.getText().toString());

            // Apply the edits!
            editor.apply();

            System.gc();
        }
    };

    private OnClickListener getAuthTokenListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                SetConfigParams();
                Log.d(TAG, "start call get auth token listener");

                getAuthTokenBackground();

                // End call JSON
                Log.d(TAG, "end call get auth token listener");

            } catch (Exception e) {
                Log.d(TAG, "Error get auth token listener",e);
                lastException = e.toString();
                returnedValue = "Error get auth token  :" + lastException;
                UpdateEtReturnValue();
            }

            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("preference_return_value", etReturnValue.getText().toString());

            // Apply the edits!
            editor.apply();

            System.gc();
        }
    };

    /**
     * get auth token background
     */
    private void getAuthTokenBackground() {

        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    Log.d(TAG, "start async process : get auth token");

                    ICallBack myCallBack = new ICallBack() {
                        public void mcallback(byte[] message_byte) {
                            if (message_byte != null) {

                                String message = new String(message_byte);
                                System.out.println("debug info: " + message);

                                try {
                                    JSONObject jsonObject = new JSONObject(message);

                                    Boolean IsError=jsonObject.getJSONObject("request").getBoolean("isError");

                                    if (IsError!=true) {
                                        returnedValue = jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").get("access_token").toString();
                                        accessToken=returnedValue;
                                        oauthConfig.access_token=accessToken;
                                    }else{
                                        returnedValue=jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").get("message").toString();
                                    }
                                } catch (Exception e) {
                                    System.out.println("Exception when creation of jsonObject : " + e.toString());
                                }
                            }
                        }
                    };

                    Log.d(TAG, "end Oauth to ccmp");
                    Push objectPush = new Push(myCallBack);
                    objectPush.GetAuthorizationToken(config,oauthConfig);//work

                    Log.d(TAG, "end async process : get auth token");
                } catch (Exception ex) {
                    msg = "Error :" + ex.getMessage();
                    Log.d(TAG, "Error on async process - get auth token - " + msg, ex);
                    returnedValue = "Error on async process - get auth token - " + msg;
                    UpdateEtReturnValue();
                    // If there is an error, don't just keep trying to register.
                    // Require the user to click a button again, or perform
                    // exponential back-off.
                }
                UpdateEtReturnValue();
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                Log.d(TAG, "async process : postExecute method");
            }
        }.execute(null, null, null);
    }

    // push Notification
    private OnClickListener registrationErrorListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
                    try {
                        SetConfigParams();
                        Log.d(TAG, "start call ccmp");

                        ICallBack myCallBack= new ICallBack() {
                            public void mcallback(byte [] message_byte)
                            {
                                String message = new String(message_byte);
                                System.out.println("debug info: "+message_byte);
                                System.out.println("debug info: " + message);
                                returnedValue = message;

                                try {
                                    JSONObject jsonObject = new JSONObject(message);

                                    Boolean IsError=jsonObject.getJSONObject("request").getBoolean("isError");

                                    if (IsError!=true) {
                                        returnedValue = jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").toString();
                                    }else{
                                        returnedValue=jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").get("message").toString();
                                    }
                                }
                                catch(JSONException e)
                                {
                                    returnedValue ="Exception when creation of jsonObject : "+ e.toString();
                                    System.out.println(returnedValue);
                                }

                            }
                        };

                        Push objectPush = new Push(myCallBack);
                        //this is should return nothing
                        objectPush.SaveErrorRegistration(config, "Errormessagecontent2");

                        Log.d(TAG, "end call ccmp");

                    } catch (Exception e) {
                        Log.d(TAG, "Error store error message to ccmp",e);

                        lastException = e.toString();
                        returnedValue = "Error store error message to ccmp :" + lastException;
                        UpdateEtReturnValue();
                    }

                    System.gc();
                }

    };

    /**
     * Save action
     */
    private void saveActionBackground() {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    Log.d(TAG, "start async process : search record");

                    ICallBack myCallBack = new ICallBack() {
                        public void mcallback(byte[] message_byte) {
                            if (message_byte != null) {

                                String message = new String(message_byte);
                                System.out.println("debug info: " + message);

                                try {

                                    JSONObject jsonObject = new JSONObject(message);

                                    Boolean IsError=jsonObject.getJSONObject("request").getBoolean("isError");

                                    if (IsError!=true) {
                                        returnedValue = jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").toString();
                                    }else{
                                        returnedValue=jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").get("message").toString();
                                    }
                                    Log.i(TAG, "output token=>" + message);
                                } catch (Exception e) {
                                    System.out.println("Exception when creation of jsonObject : " + e.toString());
                                }
                            }
                        }
                    };

                    Log.d(TAG, "end Oauth to ccmp");
                    Push objectPush = new Push(myCallBack);

                    //get selected content
                   // String strName = spinnerAction.getSelectedItem().toString();

                    //use hasmap to translate that into a corresponding id.
                    //int intId = hashActions.get(strName);


                   //staging
                  /*  String model="{\n" +
                            "        \"apiPostId\":17,\n" +
                            "        \"data\":[\n" +
                            "        {\n" +
                            "      \"name\": \"email\",\n" +
                            "      \"value\": \"tshimangadelor@gmail.com\"\n" +
                            "    },\n" +
                            "    {\n" +
                            "      \"name\": \"phone_number\",\n" +
                            "      \"value\": \"3107795656\"\n" +
                            "    },\n" +
                            "    {\n" +
                            "      \"name\": \"first_name\",\n" +
                            "      \"value\": \"delor\"\n" +
                            "    },\n" +
                            "    {\n" +
                            "      \"name\": \"last_name\",\n" +
                            "      \"value\": \"Kazadi\"\n" +
                            "    },\n" +
                            "    {\n" +
                            "      \"name\": \"phone_number_sp3_status_id\",\n" +
                            "      \"value\": \"3107795656\"\n" +
                            "    }\n" +
                            "        ]\n" +
                            "        }";*/
                    //QA
                    String model="{\n" +
                            "        \"apiPostId\":1470,\n" +
                            "        \"data\":[\n" +
                            "        {\n" +
                            "      \"name\": \"email\",\n" +
                            "      \"value\": \"tshimangadelor@gmail.com\"\n" +
                            "    },\n" +
                            "    {\n" +
                            "      \"name\": \"phone_number\",\n" +
                            "      \"value\": \"3107795656\"\n" +
                            "    },\n" +
                            "    {\n" +
                            "      \"name\": \"first_name\",\n" +
                            "      \"value\": \"delor\"\n" +
                            "    },\n" +
                            "    {\n" +
                            "      \"name\": \"last_name\",\n" +
                            "      \"value\": \"Kazadi\"\n" +
                            "    },\n" +
                            "    {\n" +
                            "      \"name\": \"phone_number_sp3_status_id\",\n" +
                            "      \"value\": \"3107795656\"\n" +
                            "    }\n" +
                            "        ]\n" +
                            "        }";

                    objectPush.AddRecipients(config,model,oauthConfig);

                    Log.d(TAG, "end async process : search record");
                } catch (Exception ex) {
                    msg = "Error :" + ex.getMessage();
                    Log.d(TAG, "Error on async process - search record - " + msg, ex);
                    returnedValue = "Error on async process - search record - " + msg;
                    UpdateEtReturnValue();
                }
                UpdateEtReturnValue();
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                Log.d(TAG, "async process : postExecute method");
            }
        }.execute(null, null, null);
    }

    /**
     * Save action
     */
    private void saveActionBackgroundWithoutSdk() {

        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    Log.d(TAG, "start async process : send action to ccmp");

                    //get selected content
                  //  String strName = spinnerAction.getSelectedItem().toString();

                    //use hasmap to translate that into a corresponding id.
                    //int intId = hashActions.get(strName);

                    // Create a new HttpClient and Post Header


                    //DTK - We are not even using this code to be removed
                    /*HttpClient httpclient = new DefaultHttpClient();

                    String defaultIdColumnName = "pktable";
                    String defaultIdColumnValue = "2d782146-cebc-421c-876b-b28d3b2fa46f";
                    String defaultUpdateColumnName = "stringvalue";

                    String urlPost = "http://" + ipCcmp + "/ats/post.aspx?cr=" + custId + "&fm=" + formId + "&s_" + defaultIdColumnName + "=" + defaultIdColumnValue+"&s_" + defaultUpdateColumnName+"=" + intId;
                    HttpPost httppost = new HttpPost(urlPost);

                    // Execute HTTP Post Request
                    HttpResponse response = httpclient.execute(httppost);
                    returnedValue = "action sent to ccmp";
                    UpdateEtReturnValue();*/

                    Log.d(TAG, "end async process : action sent");
                } catch (Exception ex) {
                    msg = "Error :" + ex.getMessage();
                    Log.d(TAG, "Error on async process - save action - " + msg, ex);
                    returnedValue = "Error on async process - save action - " + msg;
                    UpdateEtReturnValue();
                    // If there is an error, don't just keep trying to register.
                    // Require the user to click a button again, or perform
                    // exponential back-off.
                }
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                Log.d(TAG, "async process : postExecute method");
            }
        }.execute(null, null, null);
    }

    public void getRecordBackground() {

        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    Log.d(TAG, "start async process : get record");

                    ICallBack myCallBack = new ICallBack() {
                        public void mcallback(byte[] message_byte) {
                            if (message_byte != null) {

                                String message = new String(message_byte);
                                //System.out.println("debug info: " + message_byte);
                                System.out.println("debug info: " + message);
                                //etReturnValue.setText("");
                                //etReturnValue.setText(message);

                                try {

                                    JSONObject jsonObject = new JSONObject(message);

                                    Boolean IsError=jsonObject.getJSONObject("request").getBoolean("isError");

                                    if (IsError!=true) {
                                        returnedValue = jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").toString();
                                    }else{
                                        returnedValue=jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").get("message").toString();
                                    }

                                    Log.i(TAG, "output token=>" + message);
                                } catch (Exception e) {
                                    System.out.println("Exception when creation of jsonObject : " + e.toString());
                                    returnedValue = "Exception when creation of jsonObject : " + e.toString();
                                    UpdateEtReturnValue();
                                }
                            }
                        }
                    };

                    if(radioGetRecordsRecordId.isChecked()) {

                        Log.d(TAG, "end Oauth to ccmp");
                        Push objectPush = new Push(myCallBack);

                        objectPush.GetRecordsByRecordId(config, oauthConfig, query);//work
                    }
                    else
                    {

                        Log.d(TAG, "end Oauth to ccmp");
                        Push objectPush = new Push(myCallBack);

                        objectPush.GetRecordsByTableName(config, oauthConfig, query);//work
                    }

                    Log.d(TAG, "end async process : get record");
                } catch (Exception ex) {
                    msg = "Error :" + ex.getMessage();
                    Log.d(TAG, "Error on async process - get record - " + msg, ex);
                    returnedValue = "Error on async process - get record - " + msg;
                    UpdateEtReturnValue();
                }
                UpdateEtReturnValue();
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                Log.d(TAG, "async process : postExecute method");
            }
        }.execute(null, null, null);
    }


    /**
     * search record background
     */
    private void searchRecordBackground() {

        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    Log.d(TAG, "start async process : search record");

                    ICallBack myCallBack = new ICallBack() {
                        public void mcallback(byte[] message_byte) {
                            if (message_byte != null) {

                                String message = new String(message_byte);
                                System.out.println("debug info: " + message);

                                try {

                                    JSONObject jsonObject = new JSONObject(message);
                                    //returnedValue = jsonObject.get("request").toString();

                                    Boolean IsError=jsonObject.getJSONObject("request").getBoolean("isError");

                                    if (IsError!=true) {
                                        returnedValue = jsonObject.getJSONObject("request").getJSONObject("data").toString();
                                    }else{
                                        returnedValue=jsonObject.getJSONObject("request").getJSONObject("data").getJSONObject("content").get("message").toString();
                                    }

                                    Log.i(TAG, "output token=>" + message);
                                } catch (Exception e) {
                                    returnedValue = "Exception when creation of jsonObject : " + e.toString();
                                    System.out.println(returnedValue);
                                    UpdateEtReturnValue();
                                }
                            }
                        }
                    };

                    if(radioSearchRecordTableName.isChecked()) {

                        Log.d(TAG, "end Oauth to ccmp");
                        Push objectPush = new Push(myCallBack);
                        objectPush.SearchRecordByTableName(config, oauthConfig, query);//work
                    }
                    else
                    {
                        Log.d(TAG, "end Oauth to ccmp");
                        Push objectPush = new Push(myCallBack);
                        objectPush.SearchRecordsByOperation(config, oauthConfig, query);//work
                    }

                    Log.d(TAG, "end async process : search record");
                } catch (Exception ex) {
                    msg = "Error :" + ex.getMessage();
                    Log.d(TAG, "Error on async process - search record - " + msg, ex);
                    returnedValue = "Error on async process - search record - " + msg;
                    UpdateEtReturnValue();
                }
                UpdateEtReturnValue();
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                Log.d(TAG, "async process : postExecute method");
            }
        }.execute(null, null, null);
    }

    public void UpdateEtReturnValue()
    {
        //UPDATE UI param
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                etReturnValue.setText(returnedValue);
            }
        });

        SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("preference_return_value", returnedValue);

        // Apply the edits!
        editor.apply();
    }

    /**
     * Registers the application with GCM servers asynchronously.
     * <p>
     * Stores the registration ID and the app versionCode in the application's
     * shared preferences.
     */
    private void registerInBackground() {

        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    Log.d(TAG, "Begin async process : get new regid from gcm");
                    if (gcm == null) {
                        gcm = GoogleCloudMessaging.getInstance(context);
                    }
                    pushRegId = gcm.register(SENDER_ID);
                    msg = "Device registered, registration ID=" + pushRegId;
                    Log.d(TAG, msg);
                    // You should send the registration ID to your server over HTTP, so it
                    // can use GCM/HTTP or CCS to send messages to your app.
                    //sendRegistrationIdToBackend();

                    // For this demo: we don't need to send it because the device will send
                    // upstream messages to a server that echo back the message using the
                    // 'from' address in the message.

                    // Persist the regID - no need to register again.
                    storeRegistrationId(context, pushRegId);

                    //UPDATE UI param
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            etDeviceToken.setText(pushRegId);
                            returnedValue = "update device token OK";
                            UpdateEtReturnValue();

                            SharedPreferences settings = getApplicationContext().getSharedPreferences("preference_file_key", 0);
                            SharedPreferences.Editor editor = settings.edit();
                            editor.putString("preference_device_token", etDeviceToken.getText().toString());

                            // Apply the edits!
                            editor.apply();

                        }
                    });
                    Log.d(TAG, "end async process : regid stored");
                } catch (IOException ex) {
                    msg = "Error :" + ex.getMessage();
                    Log.d(TAG, "Error on async process - " + msg, ex);

                    returnedValue = "Error on async process - " + msg;
                    UpdateEtReturnValue();
                    // If there is an error, don't just keep trying to register.
                    // Require the user to click a button again, or perform
                    // exponential back-off.
                }
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                Log.d(TAG, "async process : postExecute method");
            }
        }.execute(null, null, null);
    }

    /**
     * Stores the registration ID and the app versionCode in the application's
     * {@code SharedPreferences}.
     *
     * @param context application's context.
     * @param regId registration ID
     */
    private void storeRegistrationId(Context context, String regId) {
        final SharedPreferences prefs = getGcmPreferences(context);
        int appVersion = getAppVersion(context);
        Log.d(TAG, "Store registration id");

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(PROPERTY_REG_ID, regId);
        editor.putInt(PROPERTY_APP_VERSION, appVersion);
        editor.commit();
    }

    /**
     * @return Application's {@code SharedPreferences}.
     */
    private SharedPreferences getGcmPreferences(Context context) {
        // This sample app persists the registration ID in shared preferences, but
        // how you store the regID in your app is up to you.
        return getSharedPreferences(MainActivity.class.getSimpleName(),
                Context.MODE_PRIVATE);
    }

    /**
     * Check the device to make sure it has the Google Play Services APK. If
     * it doesn't, display a dialog that allows users to download the APK from
     * the Google Play Store or enable it in the device's system settings.
     */
    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, this,
                        PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Log.d(TAG, "This device is not supported.");
                finish();
            }
            return false;
        }
        return true;
    }

    /**
     * @return Application's version code from the {@code PackageManager}.
     */
    private static int getAppVersion(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            // should never happen
            throw new RuntimeException("Could not get package name: " + e);
        }
    }


    public static String getResponseBody(HttpResponse response) {

        String response_text = null;

        HttpEntity entity = null;

        try {

            entity = response.getEntity();

            response_text = _getResponseBody(entity);

        } catch (ParseException e) {

            e.printStackTrace();

        } catch (IOException e) {

            if (entity != null) {

                try {

                    entity.consumeContent();

                } catch (IOException e1) {

                }

            }

        }

        return response_text;

    }

    public static String _getResponseBody(final HttpEntity entity) throws IOException, ParseException {

        if (entity == null) { throw new IllegalArgumentException("HTTP entity may not be null"); }

        InputStream instream = entity.getContent();

        if (instream == null) { return ""; }

        if (entity.getContentLength() > Integer.MAX_VALUE) { throw new IllegalArgumentException(

                "HTTP entity too large to be buffered in memory"); }

        String charset = getContentCharSet(entity);

        if (charset == null) {

            charset = HTTP.DEFAULT_CONTENT_CHARSET;

        }

        Reader reader = new InputStreamReader(instream, charset);

        StringBuilder buffer = new StringBuilder();

        try {

            char[] tmp = new char[1024];

            int l;

            while ((l = reader.read(tmp)) != -1) {

                buffer.append(tmp, 0, l);

            }

        } finally {

            reader.close();

        }

        return buffer.toString();

    }

    public static String getContentCharSet(final HttpEntity entity) throws ParseException {

        if (entity == null) { throw new IllegalArgumentException("HTTP entity may not be null"); }

        String charset = null;

        if (entity.getContentType() != null) {

            HeaderElement values[] = entity.getContentType().getElements();

            if (values.length > 0) {

                NameValuePair param = values[0].getParameterByName("charset");

                if (param != null) {

                    charset = param.getValue();

                }

            }

        }

        return charset;
    }
}
