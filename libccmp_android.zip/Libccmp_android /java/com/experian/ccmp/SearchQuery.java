package com.experian.ccmp;

/**
 * Created by c06753a on 8/20/15.
 */
public class SearchQuery
{
    public SearchQuery()
    {
        this.recordId="";
        this.viewId="";
        this.viewName="";
        this.prop="";
        this.columnName="";
        this.operation="";
        this.param="";
        this.page="";
        this.count ="";
    }

    public String getRecordId() {return recordId;}
    public String recordId;

    public String getViewId() {return viewId;}
    public String viewId;

    public String getViewName() {return viewName;}
    public String viewName;

    public String getProp() {return prop;}
    public String prop;

    public String getColumnName() {return columnName;}
    public String columnName;

    public String getOperation() {return operation;}
    public String operation;

    public String getParam() {return param;}
    public String param;

    public String getPage() {return page;}
    public String page;

    public String getCount() {return count;}
    public String count;
}
