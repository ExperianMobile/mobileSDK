package com.experian.ccmp;

/**
 * Created by c06753a on 8/17/15.
 */
public class OauthConfig {

    public OauthConfig()
    {
        oauth_hostname="";
        oauth_endpoint="";
        client_id="";
        username="";
        password="";
        grant_type="";
        bear_token="";
        access_token="";
        expires_in="";
        refresh_token="";
        token_type="";
    }


    public String oauth_hostname;
    public String getOauth_hostname() {
        return oauth_hostname;
    }

    public String oauth_endpoint;
    public String getOauth_endpoint() {
        return oauth_endpoint;
    }

    public String client_id;
    public String getClient_id() {
        return client_id;
    }

    public String username;
    public String getUsername() {
        return username;
    }

    public String password;
    public String getPassword() {
        return password;
    }

    public String grant_type;
    public String getGrant_type() {
        return grant_type;
    }

    public String bear_token;
    public String getBear_token() {
        return bear_token;
    }
    //response variable
    public String access_token;
    public String getAccess_token() {
        return access_token;
    }

    public String expires_in;
    public String getExpires_in() {
        return expires_in;
    }

    public String refresh_token;
    public String getRefresh_token(){return refresh_token;}

    public String token_type;
    public String getToken_type() {
        return token_type;
    }
}

