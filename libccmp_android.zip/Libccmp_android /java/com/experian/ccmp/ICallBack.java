package com.experian.ccmp;

public interface ICallBack{
    void mcallback(byte [] message);
}
