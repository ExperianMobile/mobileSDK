package com.experian.ccmp;
import  com.experian.ccmp.ICallBack;

/**
 * Created by c06753a on 7/20/15.
 */
public class Push {
    static {
        System.loadLibrary("ccmp");
    }
    public Push(ICallBack instanceCallBack)
    {
        myInterfaceCallBack=null;
        myInterfaceCallBack=instanceCallBack;
    }
    public void setCallback(ICallBack instanceCallBack)
    {
        myInterfaceCallBack=null;
        myInterfaceCallBack=instanceCallBack;
    }
    // To be called back by the native code
    private void callback(byte[] byte_message) {
        //String message = String(byte_message);
        //System.out.println("In Java with " + message);
        myInterfaceCallBack.mcallback(byte_message);
    }
    public ICallBack myInterfaceCallBack;
    //I will change all these function to void
    public native void SaveRegistration(CustomerConfig config);
    public native void DeleteRegistration(CustomerConfig config);
    public native void GetRegistration(CustomerConfig config);
    public native void SaveRegistrationWithTokenInBody(CustomerConfig config);
    public native void UpdateRegistration(CustomerConfig config);
    public native void UpdateRegistrationWithTokenInBody(CustomerConfig config);
    public native void GetRegistrationTimeStamp(CustomerConfig config);
    public native void GetToken(CustomerConfig config);
    public native void GetApplication(CustomerConfig config);
    public native void SaveErrorRegistration(CustomerConfig config, String ErrorMessage);
    public native void GetAuthorizationToken(CustomerConfig config, OauthConfig oauth);

    public native void GetRecordsByRecordId(CustomerConfig config,OauthConfig  oauth, SearchQuery query);
    public native void GetRecordsByTableName(CustomerConfig config,OauthConfig  oauth, SearchQuery query);
    public native void SearchRecordsByOperation(CustomerConfig config,OauthConfig oauth,SearchQuery query);
    public native void SearchRecordByTableName(CustomerConfig config,OauthConfig oauth,SearchQuery query);
    public native void AddRecipients(CustomerConfig config,String model, OauthConfig oauth);


}