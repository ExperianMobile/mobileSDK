package com.experian.ccmp;


/**
 * Created by c06753a on 6/24/15.
 */
public class CustomerConfig {


    public CustomerConfig()
    {
        this.appId="";
        this.custId="";
        this.token="";
        this.baseUrl="";
        this.registrationId="";
    }
    public String hostname;
    public String getHostname() {
        return hostname;
    }

    public String baseUrl;
    public String getBaseUrl() {
        return baseUrl;
    }

    public String custId;//int
    public String getCustId() {
        return custId;
    }

    public String appId;//guid
    public String getAppId() {
        return appId;
    }

    public String token;
    public String getToken() {
        return token;
    }

    public String registrationId;
    public String getRegistrationId() {
        return registrationId;
    }
}
