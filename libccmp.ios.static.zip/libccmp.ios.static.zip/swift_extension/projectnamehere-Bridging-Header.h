//
//  applicationtestregistrationios-Bridging-Header.h
//  applicationtestregistrationios
//
//  Created by Delor Tshimanga on 7/21/15.
//  Copyright (c) 2015 Stephen Benelisha. All rights reserved.
//

#ifndef applicationtestregistrationios_applicationtestregistrationios_Bridging_Header_h
#define applicationtestregistrationios_applicationtestregistrationios_Bridging_Header_h

#import "ccmp/libccmp.h"
#import "ccmp/curl.h"
#import "ccmpObjWrapperSwift.h"

#endif
