//
//  NSObject+testobjCall.m
//  applicationtestregistrationios
//
//  Created by Delor Tshimanga on 7/24/15.
//  Copyright (c) 2015 Stephen Benelisha. All rights reserved.
//

#import "ccmpObjWrapperSwift.h"
#import "applicationtestregistrationios-Swift.h"


@implementation Push

id thisClass;
-(id)init
{
    self = [super init];
    thisClass = self;
    return self;
}
- (void) saveRegistration:(CustomerConfig *)configStuct{
     SaveRegistration(configStuct,callback_SaveRegistration);
}

- (void) deleteRegistration:(CustomerConfig *)configStuct{
    DeleteRegistration(configStuct,callback_DeleteRegistration);
}
- (void) getRegistration:(CustomerConfig *)configStuct{
    GetRegistration(configStuct,callback_GetRegistration);
}
- (void) saveRegistrationWithTokenInBody:(CustomerConfig *)configStuct{
    SaveRegistrationWithTokenInBody(configStuct,callback_SaveRegistrationWithTokenInBody);
}
- (void) updateRegistration:(CustomerConfig *)configStuct{
    UpdateRegistration(configStuct,callback_UpdateRegistration);
}
- (void) updateRegistrationWithTokenInBody:(CustomerConfig *)configStuct{
    UpdateRegistrationWithTokenInBody(configStuct,callback_UpdateRegistrationWithTokenInBody);
}
- (void) getRegistrationTimeStamp:(CustomerConfig *)configStuct{
     GetRegistrationTimeStamp(configStuct,callback_GetRegistrationTimeStamp);
}
- (void) getToken:(CustomerConfig *)configStuct{
    GetToken(configStuct,callback_GetToken);
}
- (void) getApplication:(CustomerConfig *) configStuct{
    GetApplication(configStuct,callback_GetApplication);
}
- (void) saveErrorRegistration:(CustomerConfig*)configStuct:(NSString*) ErrorMsg{
    const char *ErrMsg = [ErrorMsg cStringUsingEncoding:NSASCIIStringEncoding];
    SaveErrorRegistration(configStuct,ErrMsg,callback_SaveRegistration);
}


void callback_SaveRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}
void callback_DeleteRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}
void callback_GetRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}
void callback_SaveRegistrationWithTokenInBody(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}
void callback_UpdateRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}
void callback_UpdateRegistrationWithTokenInBody(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}
void callback_GetRegistrationTimeStamp(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}
void callback_GetToken(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}
void callback_GetApplication(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}
void callback_SaveErrorRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlock:output];
}

-(NSString *) callTheBlock:(NSString *)Msg {
    if(self.block) {
        return self.block(nil, Msg, @"200");
    } else {
        return @"SDK callback error";
    }
}

@end

