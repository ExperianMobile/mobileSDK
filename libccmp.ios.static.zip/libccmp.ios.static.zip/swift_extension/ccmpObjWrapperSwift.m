//
//  NSObject+testobjCall.m
//  applicationtestregistrationios
//
//  Created by Delor Tshimanga on 7/24/15.
//  Copyright (c) 2015 Stephen Benelisha. All rights reserved.
//

#import "ccmpObjWrapperSwift.h"


@implementation Push

id thisClass;
-(id)init
{
    self = [super init];
    thisClass = self;
    return self;
}
- (void) saveRegistration:(CustomerConfig *)configStuct{
    SaveRegistration(configStuct,callback_SaveRegistration);
}

- (void) deleteRegistration:(CustomerConfig *)configStuct{
    DeleteRegistration(configStuct,callback_DeleteRegistration);
}
- (void) getRegistration:(CustomerConfig *)configStuct{
    GetRegistration(configStuct,callback_GetRegistration);
}
- (void) saveRegistrationWithTokenInBody:(CustomerConfig *)configStuct{
    SaveRegistrationWithTokenInBody(configStuct,callback_SaveRegistrationWithTokenInBody);
}
- (void) updateRegistration:(CustomerConfig *)configStuct{
    UpdateRegistration(configStuct,callback_UpdateRegistration);
}
- (void) updateRegistrationWithTokenInBody:(CustomerConfig *)configStuct{
    UpdateRegistrationWithTokenInBody(configStuct,callback_UpdateRegistrationWithTokenInBody);
}
- (void) getRegistrationTimeStamp:(CustomerConfig *)configStuct{
    GetRegistrationTimeStamp(configStuct,callback_GetRegistrationTimeStamp);
}
- (void) getToken:(CustomerConfig *)configStuct{
    GetToken(configStuct,callback_GetToken);
}
- (void) getApplication:(CustomerConfig *) configStuct{
    GetApplication(configStuct,callback_GetApplication);
}
- (void) saveErrorRegistration:(CustomerConfig*)configStuct:(NSString*) ErrorMsg{
    const char *ErrMsg = [ErrorMsg cStringUsingEncoding:NSASCIIStringEncoding];
    SaveErrorRegistration(configStuct,ErrMsg,callback_SaveRegistration);
}

- (void) AddRecipients:(CustomerConfig*)configStuct:(OAuthConfig*) oauth:(NSString*) model{
    const char *model_data = [model cStringUsingEncoding:NSASCIIStringEncoding];
    AddRecipients(configStuct,oauth,model_data,callback_GetAuthorizationToken);
}

- (void) GetAuthorizationToken:(CustomerConfig*) configStuct: (OAuthConfig*) oauth{
    LPCURL_DOWNLOAD_OBJECT test;
    GetAuthorizationToken(configStuct,oauth,callback_GetAuthorizationToken);

}

- (void) GetRecordsByRecordId:(CustomerConfig*) configStuct: (OAuthConfig*) oauth:(SearchQuery*) query{
    GetRecordsByRecordId(configStuct,oauth,query,callback_GetAuthorizationToken);
}

- (void) GetRecordsByTableName:(CustomerConfig*) configStuct: (OAuthConfig*) oauth:(SearchQuery*) query{
    GetRecordsByTableName(configStuct,oauth,query,callback_GetRecordsByTableName);
}

- (void) SearchRecordsByOperation:(CustomerConfig*) configStuct: (OAuthConfig*) oauth:(SearchQuery*) query{
    SearchRecordsByOperation(configStuct,oauth,query,callback_SearchRecordsByOperation);
}

- (void) SearchRecordByTableName:(CustomerConfig*) configStuct: (OAuthConfig*) oauth:(SearchQuery*) query{
    SearchRecordByTableName(configStuct,oauth,query,callback_SearchRecordByTableName);
}


void callback_SaveRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_DeleteRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithText:output];
}
void callback_GetRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_SaveRegistrationWithTokenInBody(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_UpdateRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_UpdateRegistrationWithTokenInBody(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_GetRegistrationTimeStamp(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_GetToken(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
    [thisClass callTheBlockWithJson:output];
}
void callback_GetApplication(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_SaveErrorRegistration(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_GetAuthorizationToken(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}

void callback_AddRecipients(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}

void callback_GetRecordsByRecordId(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}

void callback_GetRecordsByTableName(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_SearchRecordsByOperation(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}
void callback_SearchRecordByTableName(const char * message)
{
    NSString * output = [NSString stringWithUTF8String:message];
     free((char * )message);
    [thisClass callTheBlockWithJson:output];
}


-(NSString *) callTheBlockWithJson:(NSString *)Msg {
    //DTK I will deserialize all the cal here
    //new code
    NSData * data = [Msg dataUsingEncoding:NSUTF8StringEncoding];
    NSError * jsonError = nil;
    
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
    id request = [json valueForKey:@ "request"];
    if(self.block) {
        if(json) {
            
            NSString * content;
            NSDictionary* errorInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                       [request valueForKey:@ "erroMessage"], @"erroMessage",
                                       [request valueForKey:@ "isError"], @"isError",
                                       [request valueForKey:@ "responseCode"], @"responseCode",
                                       [request valueForKey:@ "data"], @"data",
                                       nil
                                       ];
            
            NSDictionary *contentDict = [errorInfo valueForKeyPath:@"data.content"];
            
            
            NSError *error;
            NSData *contentJsonData = [NSJSONSerialization dataWithJSONObject:contentDict
                                                                      options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                                        error:&error];
            
            content = [[NSString alloc] initWithData:contentJsonData encoding:NSUTF8StringEncoding];
            
            if ([[request valueForKey:@ "isError"] integerValue]) {
                NSError * emsError = [NSError errorWithDomain:@"com.experian.sdk" code:[request valueForKey:@ "responseCode"] userInfo:errorInfo];
                return self.block(emsError, content, [request valueForKey:@ "responseCode"]);
            } else {
                
                return self.block(nil, content, [request valueForKey:@ "responseCode"]);
            }
        } else if (jsonError != nil) {
            return self.block(nil, @ "SDK Json Error", @ "500");
        } else {
            return self.block(nil, [jsonError localizedDescription], @ "500");
        }
    }
    return @"SDK callback error";
}

-(NSString *) callTheBlockWithText:(NSString *)Msg {
    //DTK I will deserialize all the cal here
    //new code
    NSData * data = [Msg dataUsingEncoding:NSUTF8StringEncoding];
    NSError * jsonError = nil;
    
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
    id request = [json valueForKey:@ "request"];
    if(self.block) {
        if(json) {
            
            NSString * yourStr;
            NSDictionary* errorInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                       [request valueForKey:@ "erroMessage"], @"erroMessage",
                                       [request valueForKey:@ "isError"], @"isError",
                                       [request valueForKey:@ "responseCode"], @"responseCode",
                                       [request valueForKey:@ "data"], @"data",
                                       nil
                                       ];
            
            BOOL state = [errorInfo valueForKeyPath:@"data.content"];
            if (state == true) {
                return self.block(nil, @ "true", [request valueForKey:@ "responseCode"]);
            } else {
                return self.block(nil, @ "false", [request valueForKey:@ "responseCode"]);
            }
        }
    }
    return @"SDK callback error";
}


@end