//
//  ccmpObjWrapperSwift.h
//  applicationtestregistrationios
//
//  Created by Delor Tshimanga on 7/24/15.
//  Copyright (c) 2015 Stephen Benelisha. All rights reserved.
//
#include "ccmp/libccmp.h"
#import <Foundation/Foundation.h>

@interface Push : NSObject

@property (strong, nonatomic) id someProperty;

- (void) someMethod;
- (void) saveRegistration:(CustomerConfig*)configStuct;
- (void) deleteRegistration:(CustomerConfig*)configStuct;
- (void) getRegistration:(CustomerConfig*)configStuct;
- (void) saveRegistrationWithTokenInBody:(CustomerConfig *)configStuct;
- (void) updateRegistration:(CustomerConfig *)configStuct;
- (void) updateRegistrationWithTokenInBody:(CustomerConfig*)configStuct;
- (void) getRegistrationTimeStamp:(CustomerConfig*)configStuct;
- (void) getToken:(CustomerConfig*)configStuct;
- (void) getApplication:(CustomerConfig*)configStuct;
- (void) saveErrorRegistration:(CustomerConfig*)configStuct:(NSString*) ErrorMsg;

@property(copy, nonatomic) NSString* (^block)(NSError * error, NSString * message, NSString * ResponseCode);
-(NSString *) callTheBlock:(NSString*) Msg;
@end
