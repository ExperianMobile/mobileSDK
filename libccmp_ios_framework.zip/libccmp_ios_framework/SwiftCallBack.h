//
//  test.h
//  applicationtestregistrationios
//
//  Created by Delor Tshimanga on 7/24/15.
//  Copyright (c) 2015 Stephen Benelisha. All rights reserved.
//

SWIFT_CLASS("SwiftCallBack")
@interface SwiftCallBack
+ (SwiftCallBack *)new;
- (void)testFunction;
- (void) SaveRegistration_CallBack(message:NSString)
- (void) DeleteRegistration_CallBack(message:NSString)
- (void) GetRegistration_CallBack(message:NSString)
- (void) SaveRegistrationWithTokenInBody_CallBack(message:NSString)
- (void) UpdateRegistration_CallBack(message:NSString)
- (void) UpdateRegistrationWithTokenInBody_CallBack(message:NSString)
- (void) GetRegistrationTimeStamp_CallBack(message:NSString)
- (void) GetToken_CallBack(message:NSString)
- (void) GetApplication_CallBack(message:NSString)
- (void) SaveErrorRegistration_CallBack(message:NSString)

- (void) AddRecipients_CallBack(message:NSString)
- (void) GetAuthorizationToken_CallBack(message:NSString)
- (void) GetRecordsByRecordId_CallBack(message:NSString)
- (void) GetRecordsByTableName_CallBack(message:NSString)
- (void) SearchRecordsByOperation_CallBack(message:NSString)
- (void) SearchRecordByTableName_CallBack(message:NSString)

- (instancetype)init OBJC_DESIGNATED_INITIALIZER;
@end
