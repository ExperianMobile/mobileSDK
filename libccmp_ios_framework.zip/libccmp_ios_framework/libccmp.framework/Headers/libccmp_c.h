//
//  libccmp_v1.h
//  libccmp.v1
//
//  Created by Delor Tshimanga
//  Copyright (c) 2015 Experian Marketing Service. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <libccmp/curl.h>

#ifndef BYTE
typedef const char BYTE;
typedef char* LPBYTE;
#endif

typedef struct
{
    const char * hostname;
    const char * baseUrl;
    const char * custId;//int
    const char * appId;//guid
    const char * token;
    const char * registrationId;
}CustomerConfig;

typedef struct _CURL_DOWNLOAD_OBJECT {
    long size;
    LPBYTE data;
} CURL_DOWNLOAD_OBJECT, *LPCURL_DOWNLOAD_OBJECT;


size_t ServiceCallback(char *data, size_t size, size_t count, void* userdata);

BOOL Submit(const char * endpoint, const char * data, const char * verb, LPCURL_DOWNLOAD_OBJECT downloadObject,CustomerConfig * config);
bool Fetch(const char* endpoint, LPCURL_DOWNLOAD_OBJECT downloadObject, CustomerConfig * config);

void SaveRegistration(CustomerConfig * config, void (*getDataValue)(const char *data));
void DeleteRegistration(CustomerConfig * config,void (*getDataValue)(const char *data));
void GetRegistration(CustomerConfig * config,  void (*getDataValue)(const char *data));
void SaveRegistrationWithTokenInBody(CustomerConfig * config,  void (*getDataValue)(const char *data));
void UpdateRegistration(CustomerConfig * config,  void (*getDataValue)(const char *data));
void UpdateRegistrationWithTokenInBody(CustomerConfig * config,  void (*getDataValue)(const char *data));
void GetRegistrationTimeStamp(CustomerConfig * config,  void (*getDataValue)(const char *data));
void GetToken(CustomerConfig * config,  void (*getDataValue)(const char *data));
void GetApplication(CustomerConfig * config,  void (*getDataValue)(const char *data));
void SaveErrorRegistration(CustomerConfig * config, const char * ErrorMessage, void (*getDataValue)(const char *data));
void getDataSync(const char * data);











