//
//  libccmp_v1.h
//  libccmp.v1
//
//  Created by Delor Tshimanga
//  Copyright (c) 2015 Experian Marketing Service. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <libccmp/curl.h>

#ifndef __TEST_LIBRARY_H
#define __TEST_LIBRARY_H

#ifndef BYTE
typedef const char BYTE;
typedef char* LPBYTE;
#endif

typedef struct _CURL_DOWNLOAD_OBJECT {
    long size;
    char * data;
    char * HTTP_Code;
    char * IsError;
} CURL_DOWNLOAD_OBJECT, *LPCURL_DOWNLOAD_OBJECT;

typedef struct
{
    const char * hostname;
    const char * baseUrl;
    const char * custId;
    const char * appId;
    const char * token;
    const char * registrationId;
}CustomerConfig;

typedef struct
{
    //request variable
    const char * oauth_hostname;
    const char * oauth_endpoint;
    const char * client_id;
    const char * username;
    const char * password;
    const char * grant_type;
    const char * bear_token;
    const char * access_token;
    const char * expires_in;
    const char * refresh_token;
    const char * token_type;
}OAuthConfig;

typedef struct
{
    const char * recordId;
    const char * viewId;
    const char * viewName;
    const char * prop;
    const char * columnName;
    const char * operation;
    const char * param;
    const char * page;
    const char * count;
} SearchQuery;

static size_t ServiceCallback(void *contents, size_t size, size_t nmemb, void *userdata);

bool Submit(const char * endpoint, const char * data, const char * verb, LPCURL_DOWNLOAD_OBJECT downloadObject,CustomerConfig * config, OAuthConfig * oauth);
bool Fetch(const char* endpoint, LPCURL_DOWNLOAD_OBJECT downloadObject, CustomerConfig * config, OAuthConfig * oauth);

void SaveRegistration(CustomerConfig * config, void (*getDataValue)(const char *data));
void DeleteRegistration(CustomerConfig * config,void (*getDataValue)(const char *data));
void GetRegistration(CustomerConfig * config,  void (*getDataValue)(const char *data));
void SaveRegistrationWithTokenInBody(CustomerConfig * config,  void (*getDataValue)(const char *data));
void UpdateRegistration(CustomerConfig * config,  void (*getDataValue)(const char *data));
void UpdateRegistrationWithTokenInBody(CustomerConfig * config,  void (*getDataValue)(const char *data));
void GetRegistrationTimeStamp(CustomerConfig * config,  void (*getDataValue)(const char *data));
void GetToken(CustomerConfig * config,  void (*getDataValue)(const char *data));
void GetApplication(CustomerConfig * config,  void (*getDataValue)(const char *data));
void SaveErrorRegistration(CustomerConfig * config, const char * ErrorMessage, void (*getDataValue)(const char *data));
void getDataSync(const char * data);

void AddRecipients(CustomerConfig * config,OAuthConfig * oauth,const char * model, void (*getDataValue)(const char *data));
void GetRecordsByRecordId(CustomerConfig * config, OAuthConfig * oauth,SearchQuery * query, void (*getDataValue)(const char *data));
void GetRecordsByTableName(CustomerConfig * config,OAuthConfig * oauth, SearchQuery * query, void (*getDataValue)(const char *data));
void SearchRecordsByOperation(CustomerConfig * config,OAuthConfig * oauth,SearchQuery * query, void (*getDataValue)(const char *data));
void SearchRecordByTableName(CustomerConfig * config,OAuthConfig * oauth,SearchQuery * query, void (*getDataValue)(const char *data));

void GetAuthorizationToken(CustomerConfig * config, OAuthConfig * oauth, void (*getDataSync)(const char *data));

void httpErrorToString(long errorCode,char **ErrMsg);
void httpErrorStatus(long errorCode, char **ErrMsg);
void createResponse(char ** contentData, LPCURL_DOWNLOAD_OBJECT download);


#endif